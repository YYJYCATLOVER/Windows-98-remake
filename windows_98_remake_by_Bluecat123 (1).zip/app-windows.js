// App window creation functions extracted from script.js
import * as config from 'config';
import { createButterflyWebsite } from './butterfly-virus.js';
import { createSpyKittyWebsite } from './spykitty-app.js';
import { showDownloadNotification, createDesktopIcon, desktopIconExists } from './desktop-manager.js';

export function createNotepadContent(container) {
    container.classList.add('notepad-content');
    const textarea = document.createElement('textarea');
    textarea.placeholder = 'Type here...';
    container.appendChild(textarea);
}

export function createMinesweeperContent(container) {
    container.classList.add('minesweeper-content');
    
    // Create header with counters and face
    const header = document.createElement('div');
    header.className = 'mine-header';
    
    const mineCounter = document.createElement('div');
    mineCounter.className = 'mine-counter';
    mineCounter.textContent = '010';
    
    const face = document.createElement('div');
    face.className = 'mine-face';
    face.textContent = '😊';
    face.addEventListener('click', () => initMinesweeperGame(container));
    
    const timeCounter = document.createElement('div');
    timeCounter.className = 'mine-counter';
    timeCounter.textContent = '000';
    
    header.appendChild(mineCounter);
    header.appendChild(face);
    header.appendChild(timeCounter);
    container.appendChild(header);
    
    // Create grid
    const grid = document.createElement('div');
    grid.className = 'mine-grid';
    container.appendChild(grid);
    
    initMinesweeperGame(container);
}

export function initMinesweeperGame(container) {
    const grid = container.querySelector('.mine-grid');
    grid.innerHTML = '';
    
    const face = container.querySelector('.mine-face');
    face.textContent = '😊';
    
    const mineCounter = container.querySelector('.mine-counter:first-child');
    mineCounter.textContent = '010';
    
    const timeCounter = container.querySelector('.mine-counter:last-child');
    timeCounter.textContent = '000';
    
    // Create a 9x9 grid with 10 mines
    const gridSize = 9;
    const totalMines = 10;
    
    // Create cells
    for (let i = 0; i < gridSize * gridSize; i++) {
        const cell = document.createElement('div');
        cell.className = 'mine-cell';
        cell.dataset.index = i;
        
        cell.addEventListener('click', (e) => {
            if (e.button === 0) { // Left click
                // Simple reveal mechanics
                cell.classList.add('revealed');
                
                // Random number for cell
                const randomNum = Math.floor(Math.random() * 4);
                if (randomNum === 0) {
                    cell.style.color = 'blue';
                    cell.textContent = '1';
                } else if (randomNum === 1) {
                    cell.style.color = 'green';
                    cell.textContent = '2';
                } else if (randomNum === 2) {
                    cell.textContent = '';
                } else {
                    face.textContent = '😵';
                    cell.style.backgroundColor = 'red';
                    cell.textContent = '💣';
                    alert('Game over! You hit a mine!');
                }
            }
        });
        
        cell.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            if (!cell.classList.contains('revealed')) {
                if (cell.textContent === '🚩') {
                    cell.textContent = '';
                } else {
                    cell.textContent = '🚩';
                }
            }
        });
        
        grid.appendChild(cell);
    }
}

export function createExplorerContent(container) {
    container.classList.add('explorer-content');
    
    // Create toolbar
    const toolbar = document.createElement('div');
    toolbar.className = 'explorer-toolbar';
    
    const backButton = document.createElement('button');
    backButton.className = 'explorer-button';
    backButton.textContent = 'Back';
    
    const forwardButton = document.createElement('button');
    forwardButton.className = 'explorer-button';
    forwardButton.textContent = 'Forward';
    
    const upButton = document.createElement('button');
    upButton.className = 'explorer-button';
    upButton.textContent = 'Up';
    
    toolbar.appendChild(backButton);
    toolbar.appendChild(forwardButton);
    toolbar.appendChild(upButton);
    container.appendChild(toolbar);
    
    // Create files area
    const files = document.createElement('div');
    files.className = 'explorer-files';
    
    // Sample files
    const fileNames = ['My Documents', 'Program Files', 'Windows', 'System', 'Recycle Bin'];
    const fileIcons = [{}, {}, {}, {}, {class: 'recycle-bin'}];
    
    fileNames.forEach((name, index) => {
        const file = document.createElement('div');
        file.className = 'explorer-file';
        
        const icon = document.createElement('div');
        icon.className = 'icon-img';
        if (fileIcons[index].class) {
            icon.classList.add(fileIcons[index].class);
        }
        
        const label = document.createElement('span');
        label.textContent = name;
        
        file.appendChild(icon);
        file.appendChild(label);
        files.appendChild(file);
    });
    
    container.appendChild(files);
}

export function createMinecraftContent(container) {
    container.classList.add('minecraft-content');
    
    // Add help icon in header
    const header = document.createElement('div');
    header.className = 'minecraft-header';
    
    const title = document.createElement('h3');
    title.textContent = 'Minecraft';
    
    const helpIcon = document.createElement('div');
    helpIcon.className = 'help-icon';
    helpIcon.addEventListener('click', () => showMinecraftHelp());
    
    header.appendChild(title);
    header.appendChild(helpIcon);
    container.appendChild(header);
    
    // Minecraft content
    const content = document.createElement('div');
    content.className = 'minecraft-world';
    content.innerHTML = `
        <div class="minecraft-message">
            <h2>Minecraft Demo</h2>
            <p>This is a demo of Minecraft in Windows 98 style.</p>
            <p>Click blocks to mine them!</p>
        </div>
        <div class="minecraft-blocks"></div>
    `;
    container.appendChild(content);
    
    // Create blocks
    const blocks = content.querySelector('.minecraft-blocks');
    for (let i = 0; i < 25; i++) {
        const block = document.createElement('div');
        block.className = 'minecraft-block';
        block.addEventListener('click', (e) => {
            e.target.classList.add('mined');
            setTimeout(() => e.target.remove(), 500);
        });
        blocks.appendChild(block);
    }
}

function showMinecraftHelp() {
    alert('Minecraft Help:\n\n- Click blocks to mine them\n- This is just a demo of the Windows 98 interface\n- Real Minecraft has much more features!');
}

export function createGoogleContent(container) {
    container.classList.add('google-content');
    
    // Create toolbar
    const toolbar = document.createElement('div');
    toolbar.className = 'google-toolbar';
    
    const addressBar = document.createElement('input');
    addressBar.type = 'text';
    addressBar.className = 'google-address';
    addressBar.value = 'https://www.google.com';
    
    const goButton = document.createElement('button');
    goButton.className = 'google-button';
    goButton.textContent = 'Go';
    
    toolbar.appendChild(addressBar);
    toolbar.appendChild(goButton);
    container.appendChild(toolbar);
    
    // Create browser content area
    const content = document.createElement('div');
    content.className = 'google-browser';
    
    // Google Beta logo and search
    const googleContent = document.createElement('div');
    googleContent.className = 'google-search-container';
    googleContent.innerHTML = `
        <img src="google.jpg" alt="Google Beta" class="google-logo">
        <div class="google-search">
            <input type="text" class="google-search-input" placeholder="Search the web using Google!">
            <div class="google-buttons">
                <button>Google Search</button>
                <button>I'm Feeling Lucky</button>
            </div>
        </div>
        <div class="google-footer">
            <p>Copyright 1998 Google Inc.</p>
        </div>
    `;
    
    content.appendChild(googleContent);
    container.appendChild(content);
}

export function createWebsiteContent(container, url) {
    container.classList.add('website-content');
    
    // Create toolbar
    const toolbar = document.createElement('div');
    toolbar.className = 'google-toolbar';
    
    const addressBar = document.createElement('input');
    addressBar.type = 'text';
    addressBar.className = 'google-address';
    addressBar.value = url || '';
    
    const goButton = document.createElement('button');
    goButton.className = 'google-button';
    goButton.textContent = 'Go';
    
    goButton.addEventListener('click', () => {
        import('./website-loader.js').then(module => {
            module.loadWebsite(container, addressBar.value);
        });
    });
    
    addressBar.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            import('./website-loader.js').then(module => {
                module.loadWebsite(container, addressBar.value);
            });
        }
    });
    
    toolbar.appendChild(addressBar);
    toolbar.appendChild(goButton);
    container.appendChild(toolbar);
    
    // Create browser content area
    const content = document.createElement('div');
    content.className = 'website-browser';
    container.appendChild(content);
    
    import('./website-loader.js').then(module => {
        module.loadWebsite(container, url);
    });
}

function showDownloadedFile() {
    createDesktopIcon('iloveyou', 'ILOVEYOU.EXE', 'virus-icon');
}

function executeVirus() {
    // Show the virus message
    const dialog = document.createElement('div');
    dialog.className = 'dialog virus-dialog';
    
    const header = document.createElement('div');
    header.className = 'dialog-header';
    
    const icon = document.createElement('div');
    icon.className = 'dialog-icon';
    icon.style.backgroundImage = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle fill='%23ff0000' cx='16' cy='16' r='14'/%3E%3Cpath fill='%23ffffff' d='M14 8h4v12h-4zM14 22h4v4h-4z'/%3E%3C/svg%3E\")";
    
    const title = document.createElement('div');
    title.className = 'dialog-title';
    title.textContent = 'ILOVEYOU';
    
    header.appendChild(icon);
    header.appendChild(title);
    dialog.appendChild(header);
    
    const content = document.createElement('div');
    content.className = 'dialog-content';
    content.innerHTML = 'I love you!<br><br>BTW it\'s a WORM and starts to duplicate itself!';
    dialog.appendChild(content);
    
    const buttons = document.createElement('div');
    buttons.className = 'dialog-buttons';
    
    const okButton = document.createElement('button');
    okButton.className = 'dialog-button';
    okButton.textContent = 'OK';
    okButton.addEventListener('click', () => {
        dialog.remove();
        startVirusReplication();
    });
    
    buttons.appendChild(okButton);
    dialog.appendChild(buttons);
    
    document.body.appendChild(dialog);
    
    // Play error sound
    if (config.settings.soundEffects) {
        const errorSound = new Audio(config.settings.sounds.error);
        errorSound.play().catch(e => console.log("Audio playback failed:", e));
    }
}

// Function to start virus replication
function startVirusReplication() {
    let replicationCount = 0;
    
    function replicateVirus() {
        if (replicationCount >= config.settings.virus.replicationLimit) {
            showSystemCrashDialog();
            return;
        }
        
        const virusWindow = document.createElement('div');
        virusWindow.className = 'window virus-window';
        virusWindow.style.left = Math.random() * (window.innerWidth - 300) + 'px';
        virusWindow.style.top = Math.random() * (window.innerHeight - 200) + 'px';
        virusWindow.style.width = '250px';
        virusWindow.style.height = '150px';
        virusWindow.style.zIndex = 9999;
        
        const windowHeader = document.createElement('div');
        windowHeader.className = 'window-header';
        
        const windowTitle = document.createElement('div');
        windowTitle.className = 'window-title';
        windowTitle.textContent = 'ILOVEYOU - ' + (replicationCount + 1);
        windowHeader.appendChild(windowTitle);
        
        const windowControls = document.createElement('div');
        windowControls.className = 'window-controls';
        
        const closeButton = document.createElement('div');
        closeButton.className = 'window-button close';
        closeButton.innerHTML = 'x';
        closeButton.addEventListener('click', (e) => {
            e.stopPropagation();
            virusWindow.remove();
        });
        
        windowControls.appendChild(closeButton);
        windowHeader.appendChild(windowControls);
        virusWindow.appendChild(windowHeader);
        
        const windowContent = document.createElement('div');
        windowContent.className = 'window-content virus-content';
        windowContent.innerHTML = '<div class="virus-message">I LOVE YOU!</div>';
        virusWindow.appendChild(windowContent);
        
        document.getElementById('windows-container').appendChild(virusWindow);
        
        // Play error sound with each replication
        if (config.settings.soundEffects) {
            const errorSound = new Audio(config.settings.sounds.error);
            errorSound.play().catch(e => console.log("Audio playback failed:", e));
        }
        
        replicationCount++;
        setTimeout(replicateVirus, config.settings.virus.replicationDelay);
    }
    
    replicateVirus();
}

function showSystemCrashDialog() {
    const dialog = document.createElement('div');
    dialog.className = 'dialog system-crash';
    
    const header = document.createElement('div');
    header.className = 'dialog-header';
    header.style.backgroundColor = '#0000aa';
    
    const title = document.createElement('div');
    title.className = 'dialog-title';
    title.textContent = 'SYSTEM ERROR';
    
    header.appendChild(title);
    dialog.appendChild(header);
    
    const content = document.createElement('div');
    content.className = 'dialog-content bsod-content';
    content.innerHTML = `
        <p>A fatal exception has occurred at 0028:C0011E36 in VXD VMM(01) + 
        00010E36. The current application will be terminated.</p>
        
        <p>* Press any key to terminate the current application</p>
        <p>* Press CTRL+ALT+DEL to restart your computer</p>
    `;
    dialog.appendChild(content);
    
    const fullScreenDiv = document.createElement('div');
    fullScreenDiv.className = 'bsod-overlay';
    fullScreenDiv.appendChild(dialog);
    
    document.body.appendChild(fullScreenDiv);
    
    fullScreenDiv.addEventListener('click', () => {
        location.reload();
    });
    
    document.addEventListener('keydown', () => {
        location.reload();
    }, { once: true });
}