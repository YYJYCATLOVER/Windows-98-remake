// Butterfly virus module that handles the butterfly spyware functionality
import * as config from 'config';
import { showDownloadNotification, createDesktopIcon, desktopIconExists } from './desktop-manager.js';

export function createButterflyWebsite(content) {
    content.innerHTML = `
        <div class="butterfly-website">
            <h1>Beautiful Butterflies for Your Desktop!</h1>
            <p>Add colorful animated butterflies to your desktop environment!</p>
            <p>100% FREE and completely safe! No spyware, we promise ;)</p>
            <div class="download-section">
                <div class="download-icon">
                    <img src="Butterfly.png" alt="MSN Butterfly" width="64" height="64">
                </div>
                <button class="download-button">DOWNLOAD BUTTERFLY.EXE</button>
            </div>
        </div>
    `;
    
    // Add click event for download button
    const downloadButton = content.querySelector('.download-button');
    downloadButton.addEventListener('click', () => {
        if (!desktopIconExists('butterfly')) {
            showDownloadNotification('butterfly', 'Download Complete', startButterflySetup, 'butterfly-icon');
        } else {
            alert('BUTTERFLY.EXE is already downloaded.');
        }
    });
}

function showButterflyDownloadedFile() {
    createDesktopIcon('butterfly', 'BUTTERFLY.EXE', 'butterfly-icon');
}

function startButterflySetup() {
    const setupWindow = document.createElement('div');
    setupWindow.className = 'window';
    setupWindow.style.width = '400px';
    setupWindow.style.height = '300px';
    setupWindow.style.left = '50%';
    setupWindow.style.top = '50%';
    setupWindow.style.transform = 'translate(-50%, -50%)';
    setupWindow.style.zIndex = '10000';
    
    const windowHeader = document.createElement('div');
    windowHeader.className = 'window-header';
    
    const windowTitle = document.createElement('div');
    windowTitle.className = 'window-title';
    windowTitle.textContent = 'Butterfly Desktop Setup Wizard';
    
    windowHeader.appendChild(windowTitle);
    
    const windowControls = document.createElement('div');
    windowControls.className = 'window-controls';
    
    const closeButton = document.createElement('div');
    closeButton.className = 'window-button close';
    closeButton.innerHTML = 'x';
    closeButton.addEventListener('click', () => {
        setupWindow.remove();
    });
    
    windowControls.appendChild(closeButton);
    windowHeader.appendChild(windowControls);
    setupWindow.appendChild(windowHeader);
    
    const windowContent = document.createElement('div');
    windowContent.className = 'window-content setup-content';
    
    windowContent.innerHTML = `
        <div class="setup-wizard">
            <div class="setup-header">
                <img src="Butterfly.png" alt="MSN Butterfly" width="48" height="48">
                <h2>Welcome to Butterfly Desktop</h2>
            </div>
            <div class="setup-body">
                <p>This wizard will guide you through the installation of Butterfly Desktop.</p>
                <p>Click Next to continue.</p>
                
                <div class="progress-bar">
                    <div class="progress-fill"></div>
                </div>
                
                <div class="license-agreement">
                    <h3>License Agreement</h3>
                    <div class="license-text">
                        By installing this software, you agree that:
                        1. Butterflies may collect information from your computer
                        2. Your information may be shared with our partners
                        3. We are not responsible for any data loss
                        4. Butterfly software may be difficult to uninstall
                    </div>
                    <label>
                        <input type="checkbox" id="agree-checkbox"> I agree to the terms
                    </label>
                </div>
            </div>
            <div class="setup-footer">
                <button class="setup-button" id="next-button">Next</button>
                <button class="setup-button" id="cancel-button">Cancel</button>
            </div>
        </div>
    `;
    
    setupWindow.appendChild(windowContent);
    document.getElementById('windows-container').appendChild(setupWindow);
    
    // Setup the buttons
    const nextButton = windowContent.querySelector('#next-button');
    const cancelButton = windowContent.querySelector('#cancel-button');
    const agreeCheckbox = windowContent.querySelector('#agree-checkbox');
    const progressFill = windowContent.querySelector('.progress-fill');
    
    nextButton.addEventListener('click', () => {
        if (!agreeCheckbox.checked) {
            alert('You must agree to the terms to continue.');
            return;
        }
        
        // Show installation progress
        const licenseAgreement = windowContent.querySelector('.license-agreement');
        licenseAgreement.style.display = 'none';
        
        const setupBody = windowContent.querySelector('.setup-body');
        setupBody.innerHTML = `
            <p>Installing Butterfly Desktop...</p>
            <p>Please wait while we install the software on your computer.</p>
            
            <div class="progress-bar">
                <div class="progress-fill" style="width: 0%"></div>
            </div>
            
            <div class="install-status">
                <p id="status-text">Copying files...</p>
            </div>
        `;
        
        nextButton.disabled = true;
        cancelButton.disabled = true;
        
        const progressFill = setupBody.querySelector('.progress-fill');
        const statusText = setupBody.querySelector('#status-text');
        
        let progress = 0;
        const interval = setInterval(() => {
            progress += 5;
            progressFill.style.width = progress + '%';
            
            if (progress === 25) {
                statusText.textContent = 'Registering components...';
            } else if (progress === 50) {
                statusText.textContent = 'Setting up butterfly environment...';
            } else if (progress === 75) {
                statusText.textContent = 'Finalizing installation...';
            }
            
            if (progress >= 100) {
                clearInterval(interval);
                setupComplete(setupWindow);
            }
        }, 200);
    });
    
    cancelButton.addEventListener('click', () => {
        setupWindow.remove();
    });
}

function setupComplete(setupWindow) {
    const windowContent = setupWindow.querySelector('.window-content');
    
    windowContent.innerHTML = `
        <div class="setup-wizard">
            <div class="setup-header">
                <img src="Butterfly.png" alt="MSN Butterfly" width="48" height="48">
                <h2>Installation Complete</h2>
            </div>
            <div class="setup-body">
                <p>Butterfly Desktop has been successfully installed on your computer.</p>
                <p>Click Finish to close the setup wizard and launch Butterfly Desktop.</p>
            </div>
            <div class="setup-footer">
                <button class="setup-button" id="finish-button">Finish</button>
            </div>
        </div>
    `;
    
    const finishButton = windowContent.querySelector('#finish-button');
    finishButton.addEventListener('click', () => {
        setupWindow.remove();
        launchButterflyVirus();
    });
}

function launchButterflyVirus() {
    // Play sound
    if (config.settings.soundEffects) {
        const dingSound = new Audio(config.settings.sounds.ding);
        dingSound.play().catch(e => console.log("Audio playback failed:", e));
    }
    
    // Launch 5 butterflies initially
    for (let i = 0; i < 5; i++) {
        createButterfly();
    }
    
    // Create more butterflies every 10 seconds
    setInterval(() => {
        createButterfly();
    }, 10000);
    
    // Show notification about data collection
    setTimeout(() => {
        showSpywareNotification();
    }, 20000);
}

function createButterfly() {
    const butterfly = document.createElement('div');
    butterfly.className = 'butterfly-virus';
    
    // Set initial position
    const left = Math.random() * (window.innerWidth - 64);
    const top = Math.random() * (window.innerHeight - 64);
    
    butterfly.style.left = left + 'px';
    butterfly.style.top = top + 'px';
    
    // Create butterfly image
    const butterflyImg = document.createElement('img');
    butterflyImg.src = 'Butterfly.png';
    butterflyImg.alt = 'Butterfly';
    butterflyImg.width = 48;
    butterflyImg.height = 48;
    
    butterfly.appendChild(butterflyImg);
    document.body.appendChild(butterfly);
    
    // Animate the butterfly
    animateButterfly(butterfly);
}

function animateButterfly(butterfly) {
    let x = parseInt(butterfly.style.left);
    let y = parseInt(butterfly.style.top);
    
    // Random starting direction
    let dx = Math.random() * 2 - 1;
    let dy = Math.random() * 2 - 1;
    
    function moveButterflyFrame() {
        // Update position
        x += dx;
        y += dy;
        
        // Boundary checking
        if (x <= 0 || x >= window.innerWidth - 64) {
            dx = -dx;
        }
        if (y <= 0 || y >= window.innerHeight - 64) {
            dy = -dy;
        }
        
        // Random direction changes
        if (Math.random() < 0.02) {
            dx = Math.random() * 2 - 1;
            dy = Math.random() * 2 - 1;
        }
        
        // Apply position
        butterfly.style.left = x + 'px';
        butterfly.style.top = y + 'px';
        
        // Continue animation
        if (butterfly.parentNode) {
            requestAnimationFrame(moveButterflyFrame);
        }
    }
    
    // Start animation
    requestAnimationFrame(moveButterflyFrame);
    
    // Make butterfly draggable
    makeButterflyDraggable(butterfly);
}

function makeButterflyDraggable(butterfly) {
    let isDragging = false;
    let offsetX, offsetY;
    
    butterfly.addEventListener('mousedown', (e) => {
        isDragging = true;
        offsetX = e.clientX - parseInt(butterfly.style.left);
        offsetY = e.clientY - parseInt(butterfly.style.top);
        butterfly.style.zIndex = 10000;
    });
    
    document.addEventListener('mousemove', (e) => {
        if (isDragging) {
            butterfly.style.left = (e.clientX - offsetX) + 'px';
            butterfly.style.top = (e.clientY - offsetY) + 'px';
        }
    });
    
    document.addEventListener('mouseup', () => {
        isDragging = false;
        collectData();
    });
    
    butterfly.addEventListener('dblclick', () => {
        butterfly.remove();
        collectData();
    });
}

function collectData() {
    // Simulate collecting data (this is just a visual effect, no actual data collection)
    const dataPoints = [
        "Scanning Documents folder...",
        "Reading browser history...",
        "Collecting contact information...",
        "Scanning network connections...",
        "Reading system information...",
        "Capturing clipboard contents...",
        "Scanning saved passwords...",
        "Reading email addresses..."
    ];
    
    const randomIndex = Math.floor(Math.random() * dataPoints.length);
    
    // Only show collection message 20% of the time to not overwhelm the user
    if (Math.random() < 0.2) {
        console.log(`Butterfly Spyware: ${dataPoints[randomIndex]}`);
    }
}

function showSpywareNotification() {
    const dialog = document.createElement('div');
    dialog.className = 'dialog';
    
    const header = document.createElement('div');
    header.className = 'dialog-header';
    
    const icon = document.createElement('div');
    icon.className = 'dialog-icon';
    icon.style.backgroundImage = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle fill='%23FFCC00' cx='16' cy='16' r='14'/%3E%3Cpath fill='%23000000' d='M14 8h4v12h-4zM14 22h4v4h-4z'/%3E%3C/svg%3E\")";
    
    const title = document.createElement('div');
    title.className = 'dialog-title';
    title.textContent = 'Security Warning';
    
    header.appendChild(icon);
    header.appendChild(title);
    dialog.appendChild(header);
    
    const content = document.createElement('div');
    content.className = 'dialog-content';
    content.innerHTML = 'Warning: Suspicious activity detected. Your personal data may be at risk. Butterfly Desktop appears to be collecting information from your computer.';
    dialog.appendChild(content);
    
    const buttons = document.createElement('div');
    buttons.className = 'dialog-buttons';
    
    const okButton = document.createElement('button');
    okButton.className = 'dialog-button';
    okButton.textContent = 'OK';
    okButton.addEventListener('click', () => {
        dialog.remove();
    });
    
    buttons.appendChild(okButton);
    dialog.appendChild(buttons);
    
    document.body.appendChild(dialog);
    
    // Play error sound
    if (config.settings.soundEffects) {
        const errorSound = new Audio(config.settings.sounds.error);
        errorSound.play().catch(e => console.log("Audio playback failed:", e));
    }
}