// WINCAT virus module that handles the WINCAT trojan functionality
import * as config from 'config';
import { showDownloadNotification, createDesktopIcon, desktopIconExists } from './desktop-manager.js';

export function createWincatWebsite(content) {
    content.innerHTML = `
        <div class="wincat-website">
            <h1>WINCAT VIRUS - For Educational Purposes Only</h1>
            <p>WARNING: This is a simulated virus for demonstration purposes.</p>
            <p>WINCAT is a dangerous Trojan that can destroy your BIOS. DO NOT USE ON REAL SYSTEMS!</p>
            <div class="download-section">
                <div class="download-icon">
                    <svg width="64" height="64" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10" fill="#ff2222" />
                        <path d="M8,12 C8,9 12,6 16,9" stroke="white" stroke-width="1.5" fill="none" />
                        <path d="M8,12 C8,15 12,18 16,15" stroke="white" stroke-width="1.5" fill="none" />
                        <circle cx="9" cy="9" r="1" fill="white" />
                        <circle cx="9" cy="15" r="1" fill="white" />
                    </svg>
                </div>
                <button class="download-button">DOWNLOAD WINCAT.EXE</button>
            </div>
        </div>
    `;
    
    // Add click event for download button
    const downloadButton = content.querySelector('.download-button');
    downloadButton.addEventListener('click', () => {
        if (!desktopIconExists('wincat')) {
            showDownloadNotification('wincat', 'Download Complete', executeWincat, 'wincat-icon');
        } else {
            alert('WINCAT.EXE is already downloaded.');
        }
    });
}

function executeWincat() {
    // First confirmation dialog
    const dialog1 = document.createElement('div');
    dialog1.className = 'dialog';
    
    const header1 = document.createElement('div');
    header1.className = 'dialog-header';
    
    const icon1 = document.createElement('div');
    icon1.className = 'dialog-icon';
    icon1.style.backgroundImage = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle fill='%23ff0000' cx='16' cy='16' r='14'/%3E%3Cpath fill='%23ffffff' d='M14 8h4v12h-4zM14 22h4v4h-4z'/%3E%3C/svg%3E\")";
    
    const title1 = document.createElement('div');
    title1.className = 'dialog-title';
    title1.textContent = 'WINCAT.EXE';
    
    header1.appendChild(icon1);
    header1.appendChild(title1);
    dialog1.appendChild(header1);
    
    const content1 = document.createElement('div');
    content1.className = 'dialog-content';
    content1.innerHTML = 'Run? This is a Trojan!';
    dialog1.appendChild(content1);
    
    const buttons1 = document.createElement('div');
    buttons1.className = 'dialog-buttons';
    
    const okButton1 = document.createElement('button');
    okButton1.className = 'dialog-button';
    okButton1.textContent = 'OK';
    okButton1.addEventListener('click', () => {
        dialog1.remove();
        showSecondWarning();
    });
    
    const cancelButton1 = document.createElement('button');
    cancelButton1.className = 'dialog-button';
    cancelButton1.textContent = 'Cancel';
    cancelButton1.addEventListener('click', () => {
        dialog1.remove();
    });
    
    buttons1.appendChild(okButton1);
    buttons1.appendChild(cancelButton1);
    dialog1.appendChild(buttons1);
    
    document.body.appendChild(dialog1);
    
    // Play error sound
    if (config.settings.soundEffects) {
        const errorSound = new Audio(config.settings.sounds.error);
        errorSound.play().catch(e => console.log("Audio playback failed:", e));
    }
}

function showSecondWarning() {
    const dialog2 = document.createElement('div');
    dialog2.className = 'dialog';
    
    const header2 = document.createElement('div');
    header2.className = 'dialog-header';
    
    const icon2 = document.createElement('div');
    icon2.className = 'dialog-icon';
    icon2.style.backgroundImage = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle fill='%23ff0000' cx='16' cy='16' r='14'/%3E%3Cpath fill='%23ffffff' d='M14 8h4v12h-4zM14 22h4v4h-4z'/%3E%3C/svg%3E\")";
    
    const title2 = document.createElement('div');
    title2.className = 'dialog-title';
    title2.textContent = 'FINAL WARNING';
    
    header2.appendChild(icon2);
    header2.appendChild(title2);
    dialog2.appendChild(header2);
    
    const content2 = document.createElement('div');
    content2.className = 'dialog-content';
    content2.innerHTML = 'SURE??? THIS WILL KILL THE BIOS!!!';
    dialog2.appendChild(content2);
    
    const buttons2 = document.createElement('div');
    buttons2.className = 'dialog-buttons';
    
    const okButton2 = document.createElement('button');
    okButton2.className = 'dialog-button';
    okButton2.textContent = 'Continue Anyway';
    okButton2.addEventListener('click', () => {
        dialog2.remove();
        startWincatExecution();
    });
    
    const cancelButton2 = document.createElement('button');
    cancelButton2.className = 'dialog-button';
    cancelButton2.textContent = 'Cancel';
    cancelButton2.addEventListener('click', () => {
        dialog2.remove();
    });
    
    buttons2.appendChild(okButton2);
    buttons2.appendChild(cancelButton2);
    dialog2.appendChild(buttons2);
    
    document.body.appendChild(dialog2);
    
    // Play error sound
    if (config.settings.soundEffects) {
        const errorSound = new Audio(config.settings.sounds.error);
        errorSound.play().catch(e => console.log("Audio playback failed:", e));
    }
}

function startWincatExecution() {
    // Create notepad with warning
    const notepadWindow = document.createElement('div');
    notepadWindow.className = 'window wincat-window';
    notepadWindow.style.width = '400px';
    notepadWindow.style.height = '300px';
    notepadWindow.style.left = '50%';
    notepadWindow.style.top = '50%';
    notepadWindow.style.transform = 'translate(-50%, -50%)';
    notepadWindow.style.zIndex = '10000';
    
    const windowHeader = document.createElement('div');
    windowHeader.className = 'window-header';
    
    const windowTitle = document.createElement('div');
    windowTitle.className = 'window-title';
    windowTitle.textContent = 'WINCAT WARNING - Notepad';
    
    windowHeader.appendChild(windowTitle);
    
    const windowControls = document.createElement('div');
    windowControls.className = 'window-controls';
    
    const closeButton = document.createElement('div');
    closeButton.className = 'window-button close';
    closeButton.innerHTML = 'x';
    closeButton.addEventListener('click', () => {
        notepadWindow.remove();
    });
    
    windowControls.appendChild(closeButton);
    windowHeader.appendChild(windowControls);
    notepadWindow.appendChild(windowHeader);
    
    const windowContent = document.createElement('div');
    windowContent.className = 'window-content notepad-content';
    
    const textarea = document.createElement('textarea');
    textarea.readOnly = true;
    textarea.value = "YOUR PC IS GONE BY THE WINCAT VIRUS\nDO NOT TRY TO KILL WINCAT OR YOUR BIOS WILL DIE!\nHAVE FUN!";
    windowContent.appendChild(textarea);
    
    notepadWindow.appendChild(windowContent);
    document.getElementById('windows-container').appendChild(notepadWindow);
    
    // Start the virus sequence
    startVirusSequence();
}

function startVirusSequence() {
    let stage = 0;
    const maxStage = 5;
    
    // Play error sound
    function playErrorSound() {
        if (config.settings.soundEffects) {
            const errorSound = new Audio(config.settings.sounds.error);
            errorSound.play().catch(e => console.log("Audio playback failed:", e));
        }
    }
    
    // Stage 1: Open websites every 4 seconds
    function openRandomWebsites() {
        if (stage >= 1) return;
        
        const websites = [
            'https://google.com',
            'https://spykitty.com',
            'https://butterflydownload.com',
            'https://aboutvirus.com',
            'https://iloveyou.com'
        ];
        
        let websiteCount = 0;
        
        const websiteInterval = setInterval(() => {
            if (websiteCount >= 3 || stage >= 1) {
                clearInterval(websiteInterval);
                return;
            }
            
            const randomSite = websites[Math.floor(Math.random() * websites.length)];
            
            const windowObj = document.createElement('div');
            windowObj.className = 'window wincat-window';
            windowObj.style.width = '500px';
            windowObj.style.height = '400px';
            windowObj.style.left = (100 + Math.random() * 300) + 'px';
            windowObj.style.top = (50 + Math.random() * 200) + 'px';
            windowObj.style.zIndex = '9999';
            
            const windowHeader = document.createElement('div');
            windowHeader.className = 'window-header';
            
            const windowTitle = document.createElement('div');
            windowTitle.className = 'window-title';
            windowTitle.textContent = 'Internet Explorer';
            
            windowHeader.appendChild(windowTitle);
            
            const windowControls = document.createElement('div');
            windowControls.className = 'window-controls';
            
            const closeButton = document.createElement('div');
            closeButton.className = 'window-button close';
            closeButton.innerHTML = 'x';
            
            windowControls.appendChild(closeButton);
            windowHeader.appendChild(windowControls);
            windowObj.appendChild(windowHeader);
            
            const windowContent = document.createElement('div');
            windowContent.className = 'window-content website-content';
            
            const toolbar = document.createElement('div');
            toolbar.className = 'google-toolbar';
            
            const addressBar = document.createElement('input');
            addressBar.type = 'text';
            addressBar.className = 'google-address';
            addressBar.value = randomSite;
            
            toolbar.appendChild(addressBar);
            windowContent.appendChild(toolbar);
            
            const content = document.createElement('div');
            content.className = 'website-browser';
            content.innerHTML = `
                <div style="padding: 20px; text-align: center;">
                    <h1>WINCAT TOOK OVER YOUR BROWSER</h1>
                    <p>Your computer is now infected with WINCAT Trojan!</p>
                </div>
            `;
            
            windowContent.appendChild(content);
            windowObj.appendChild(windowContent);
            
            document.getElementById('windows-container').appendChild(windowObj);
            websiteCount++;
            
            playErrorSound();
            
        }, 4000);
        
        // Move to next stage after 10 seconds
        setTimeout(() => {
            stage = 1;
        }, 10000);
    }
    
    // Stage 2: Open random applications
    function openRandomApps() {
        if (stage >= 2) return;
        
        const apps = ['notepad', 'minesweeper', 'explorer', 'about'];
        
        let appCount = 0;
        
        const appInterval = setInterval(() => {
            if (appCount >= 5 || stage >= 2) {
                clearInterval(appInterval);
                return;
            }
            
            const randomApp = apps[Math.floor(Math.random() * apps.length)];
            
            if (typeof window.openApp === 'function') {
                window.openApp(randomApp);
            }
            
            appCount++;
            playErrorSound();
            
        }, 2000);
        
        // Move to next stage after 10 seconds
        setTimeout(() => {
            stage = 2;
        }, 20000);
    }
    
    // Stage 3: Change colors and play sounds
    function changeColorsAndSounds() {
        if (stage >= 3) return;
        
        const colors = ['#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF'];
        let colorIndex = 0;
        
        const colorInterval = setInterval(() => {
            if (stage >= 3) {
                clearInterval(colorInterval);
                document.body.style.backgroundColor = '';
                return;
            }
            
            document.body.style.backgroundColor = colors[colorIndex % colors.length];
            colorIndex++;
            
            playErrorSound();
            
        }, 1000);
        
        // Move to next stage after 6 seconds
        setTimeout(() => {
            stage = 3;
        }, 26000);
    }
    
    // Stage 4: Screen duplication effect
    function createScreenDuplication() {
        if (stage >= 4) return;
        
        // Create a container for the screen duplications
        const duplicationContainer = document.createElement('div');
        duplicationContainer.className = 'wincat-duplication-container';
        duplicationContainer.style.position = 'fixed';
        duplicationContainer.style.top = '0';
        duplicationContainer.style.left = '0';
        duplicationContainer.style.width = '100%';
        duplicationContainer.style.height = '100%';
        duplicationContainer.style.pointerEvents = 'none';
        duplicationContainer.style.zIndex = '9998';
        
        document.body.appendChild(duplicationContainer);
        
        // Create initial screenshot
        html2canvas(document.body).then(canvas => {
            const initialScreenshot = document.createElement('div');
            initialScreenshot.className = 'wincat-screenshot';
            initialScreenshot.style.position = 'absolute';
            initialScreenshot.style.width = '80%';
            initialScreenshot.style.height = '80%';
            initialScreenshot.style.top = '10%';
            initialScreenshot.style.left = '10%';
            initialScreenshot.style.backgroundImage = `url(${canvas.toDataURL()})`;
            initialScreenshot.style.backgroundSize = 'cover';
            initialScreenshot.style.border = '2px solid #000';
            initialScreenshot.style.zIndex = '9999';
            
            duplicationContainer.appendChild(initialScreenshot);
            
            let scale = 0.8;
            
            const duplicationInterval = setInterval(() => {
                if (stage >= 4) {
                    clearInterval(duplicationInterval);
                    duplicationContainer.remove();
                    return;
                }
                
                scale *= 0.9;
                
                const newScreenshot = document.createElement('div');
                newScreenshot.className = 'wincat-screenshot';
                newScreenshot.style.position = 'absolute';
                newScreenshot.style.width = (scale * 100) + '%';
                newScreenshot.style.height = (scale * 100) + '%';
                newScreenshot.style.top = ((1 - scale) / 2 * 100) + '%';
                newScreenshot.style.left = ((1 - scale) / 2 * 100) + '%';
                newScreenshot.style.backgroundImage = `url(${canvas.toDataURL()})`;
                newScreenshot.style.backgroundSize = 'cover';
                newScreenshot.style.border = '2px solid #000';
                newScreenshot.style.zIndex = '10000';
                
                duplicationContainer.appendChild(newScreenshot);
                
                playErrorSound();
                
            }, 2000);
        });
        
        // Move to next stage after 13 seconds
        setTimeout(() => {
            stage = 4;
        }, 39000);
    }
    
    // Stage 5: Error popups
    function showErrorPopups() {
        if (stage >= 5) return;
        
        let popupCount = 0;
        
        const popupInterval = setInterval(() => {
            if (popupCount >= 5 || stage >= 5) {
                clearInterval(popupInterval);
                return;
            }
            
            const dialog = document.createElement('div');
            dialog.className = 'dialog';
            dialog.style.left = (50 + Math.random() * 400) + 'px';
            dialog.style.top = (50 + Math.random() * 300) + 'px';
            dialog.style.transform = 'none';
            
            const header = document.createElement('div');
            header.className = 'dialog-header';
            
            const icon = document.createElement('div');
            icon.className = 'dialog-icon';
            icon.style.backgroundImage = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle fill='%23ff0000' cx='16' cy='16' r='14'/%3E%3Cpath fill='%23ffffff' d='M14 8h4v12h-4zM14 22h4v4h-4z'/%3E%3C/svg%3E\")";
            
            const title = document.createElement('div');
            title.className = 'dialog-title';
            title.textContent = 'System Error';
            
            header.appendChild(icon);
            header.appendChild(title);
            dialog.appendChild(header);
            
            const content = document.createElement('div');
            content.className = 'dialog-content';
            content.innerHTML = 'Still Using This PC?';
            dialog.appendChild(content);
            
            const buttons = document.createElement('div');
            buttons.className = 'dialog-buttons';
            
            const okButton = document.createElement('button');
            okButton.className = 'dialog-button';
            okButton.textContent = 'OK';
            okButton.addEventListener('click', () => {
                dialog.remove();
            });
            
            buttons.appendChild(okButton);
            dialog.appendChild(buttons);
            
            document.body.appendChild(dialog);
            
            popupCount++;
            playErrorSound();
            
        }, 2000);
        
        // Final stage after 10 seconds
        setTimeout(() => {
            stage = 5;
            showBIOSDeath();
        }, 49000);
    }
    
    // Final stage: BIOS death
    function showBIOSDeath() {
        // Remove all windows and dialogs
        document.querySelectorAll('.window, .dialog').forEach(el => el.remove());
        
        // Create BIOS death screen
        const biosDeathScreen = document.createElement('div');
        biosDeathScreen.className = 'bios-death-screen';
        biosDeathScreen.style.position = 'fixed';
        biosDeathScreen.style.top = '0';
        biosDeathScreen.style.left = '0';
        biosDeathScreen.style.width = '100%';
        biosDeathScreen.style.height = '100%';
        biosDeathScreen.style.backgroundColor = 'black';
        biosDeathScreen.style.color = 'red';
        biosDeathScreen.style.fontFamily = 'monospace';
        biosDeathScreen.style.padding = '50px';
        biosDeathScreen.style.zIndex = '99999';
        biosDeathScreen.style.display = 'flex';
        biosDeathScreen.style.flexDirection = 'column';
        biosDeathScreen.style.justifyContent = 'center';
        biosDeathScreen.style.alignItems = 'center';
        
        biosDeathScreen.innerHTML = `
            <div style="margin-bottom: 20px;">
                <h1 style="color: red; font-size: 32px; text-align: center;">FATAL ERROR</h1>
                <p style="color: red; font-size: 20px; text-align: center;">BIOS CORRUPTED BY WINCAT</p>
            </div>
            <div style="margin-bottom: 20px; text-align: left; width: 80%;">
                <p>WINCAT VIRUS HAS DESTROYED YOUR BIOS</p>
                <p>SYSTEM HALTED</p>
                <p>YOUR PC IS NOW USELESS DUE TO DEAD BIOS</p>
                <p>HAVE FUN</p>
            </div>
        `;
        
        document.body.appendChild(biosDeathScreen);
        
        // Play error sound
        playErrorSound();
        
        // Show Nyan Cat after 4 seconds
        setTimeout(() => {
            biosDeathScreen.innerHTML = `
                <iframe width="100%" height="100%" src="https://www.nyan.cat/" frameborder="0"></iframe>
            `;
            
            // Add a button to restart the computer
            const restartButton = document.createElement('button');
            restartButton.style.position = 'fixed';
            restartButton.style.bottom = '20px';
            restartButton.style.right = '20px';
            restartButton.style.padding = '10px 20px';
            restartButton.style.fontSize = '16px';
            restartButton.style.zIndex = '100000';
            restartButton.textContent = 'Restart Computer';
            
            restartButton.addEventListener('click', () => {
                location.reload();
            });
            
            document.body.appendChild(restartButton);
            
        }, 4000);
    }
    
    // Start the HTML2Canvas polyfill
    function startHTML2Canvas() {
        // Create a simple polyfill if HTML2Canvas is not available
        if (typeof html2canvas !== 'function') {
            window.html2canvas = function(element) {
                return new Promise((resolve) => {
                    const canvas = document.createElement('canvas');
                    canvas.width = window.innerWidth;
                    canvas.height = window.innerHeight;
                    const ctx = canvas.getContext('2d');
                    
                    // Fill with a basic gradient
                    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
                    gradient.addColorStop(0, '#ff0000');
                    gradient.addColorStop(0.5, '#00ff00');
                    gradient.addColorStop(1, '#0000ff');
                    
                    ctx.fillStyle = gradient;
                    ctx.fillRect(0, 0, canvas.width, canvas.height);
                    
                    resolve(canvas);
                });
            };
        }
    }
    
    // Start the sequence
    startHTML2Canvas();
    openRandomWebsites();
    
    setTimeout(() => {
        openRandomApps();
    }, 10000);
    
    setTimeout(() => {
        changeColorsAndSounds();
    }, 20000);
    
    setTimeout(() => {
        createScreenDuplication();
    }, 26000);
    
    setTimeout(() => {
        showErrorPopups();
    }, 39000);
}