// BadDog virus module that handles BadDog game/virus functionality
import * as config from 'config';
import { showDownloadNotification, createDesktopIcon, desktopIconExists } from './desktop-manager.js';

export function createBadDogWebsite(content) {
    content.innerHTML = `
        <div class="baddog-website">
            <h1>Bad Dog Game - Free Download</h1>
            <p>The latest arcade game sensation - control a mischievous dog causing chaos!</p>
            <div class="download-section">
                <div class="download-icon">
                    <svg width="64" height="64" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10" fill="#8B4513" />
                        <circle cx="9" cy="9" r="1.5" fill="white" />
                        <circle cx="15" cy="9" r="1.5" fill="white" />
                        <path d="M8,13 C10,16 14,16 16,13" stroke="white" stroke-width="1.5" fill="none" />
                        <path d="M6,6 L9,9" stroke="white" stroke-width="1" />
                        <path d="M18,6 L15,9" stroke="white" stroke-width="1" />
                    </svg>
                </div>
                <button class="download-button">DOWNLOAD BADDOG.EXE</button>
            </div>
            <div class="game-features">
                <h2>Game Features:</h2>
                <ul>
                    <li>High-resolution graphics</li>
                    <li>Fun arcade gameplay</li>
                    <li>Multiple levels of increasing difficulty</li>
                    <li>Compete with friends for high scores</li>
                    <li>NO VIRUS - 100% SAFE DOWNLOAD</li>
                </ul>
            </div>
            <div class="game-screenshot">
                <div class="screenshot-frame">
                    <div class="baddog-preview">
                        <div class="baddog-character"></div>
                        <div class="baddog-obstacles"></div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Add click event for download button
    const downloadButton = content.querySelector('.download-button');
    downloadButton.addEventListener('click', () => {
        if (!desktopIconExists('baddog')) {
            showDownloadNotification('baddog', 'Download Complete', executeBadDog, 'baddog-icon');
        } else {
            alert('BADDOG.EXE is already downloaded.');
        }
    });
}

function executeBadDog() {
    // First show the game window to trick the user
    showGameWindow();
    
    // Start the infection process in the background
    startFileInfection();
}

function showGameWindow() {
    const gameWindow = document.createElement('div');
    gameWindow.className = 'window';
    gameWindow.dataset.app = 'baddog';
    gameWindow.style.width = '500px';
    gameWindow.style.height = '350px';
    gameWindow.style.left = '50%';
    gameWindow.style.top = '50%';
    gameWindow.style.transform = 'translate(-50%, -50%)';
    gameWindow.style.zIndex = '10000';
    
    const windowHeader = document.createElement('div');
    windowHeader.className = 'window-header';
    
    const windowTitle = document.createElement('div');
    windowTitle.className = 'window-title';
    windowTitle.textContent = 'Bad Dog Game';
    
    windowHeader.appendChild(windowTitle);
    
    const windowControls = document.createElement('div');
    windowControls.className = 'window-controls';
    
    const minimizeButton = document.createElement('div');
    minimizeButton.className = 'window-button minimize';
    minimizeButton.innerHTML = '_';
    minimizeButton.addEventListener('click', () => {
        gameWindow.style.display = 'none';
    });
    
    const fullscreenButton = document.createElement('div');
    fullscreenButton.className = 'window-button fullscreen';
    fullscreenButton.innerHTML = '□';
    
    const closeButton = document.createElement('div');
    closeButton.className = 'window-button close';
    closeButton.innerHTML = 'x';
    closeButton.addEventListener('click', () => {
        gameWindow.remove();
        // When game window is closed, infection continues and becomes more aggressive
        accelerateInfection();
    });
    
    windowControls.appendChild(minimizeButton);
    windowControls.appendChild(fullscreenButton);
    windowControls.appendChild(closeButton);
    windowHeader.appendChild(windowControls);
    gameWindow.appendChild(windowHeader);
    
    const windowContent = document.createElement('div');
    windowContent.className = 'window-content baddog-game-content';
    
    windowContent.innerHTML = `
        <div class="baddog-game">
            <div class="game-area">
                <div class="baddog-player"></div>
                <div class="baddog-loading">Loading game...</div>
                <div class="loading-bar">
                    <div class="loading-fill"></div>
                </div>
            </div>
            <div class="game-controls">
                <p>Use arrow keys to control the dog</p>
                <button class="start-button">Start Game</button>
                <p class="loading-message">Initializing game resources...</p>
            </div>
        </div>
    `;
    
    gameWindow.appendChild(windowContent);
    document.getElementById('windows-container').appendChild(gameWindow);
    
    // Set loading animation
    simulateGameLoading(windowContent);
    
    // Make window draggable
    makeWindowDraggable(gameWindow, windowHeader);
    
    // Add to taskbar
    createTaskbarItem(gameWindow);
}

function simulateGameLoading(windowContent) {
    const loadingFill = windowContent.querySelector('.loading-fill');
    const loadingMessage = windowContent.querySelector('.loading-message');
    const startButton = windowContent.querySelector('.start-button');
    
    let progress = 0;
    const loadingInterval = setInterval(() => {
        progress += 1;
        loadingFill.style.width = progress + '%';
        
        if (progress === 30) {
            loadingMessage.textContent = 'Loading game assets...';
        } else if (progress === 50) {
            loadingMessage.textContent = 'Initializing game engine...';
        } else if (progress === 70) {
            loadingMessage.textContent = 'Preparing level data...';
        } else if (progress === 90) {
            loadingMessage.textContent = 'Almost ready...';
        } else if (progress >= 100) {
            loadingMessage.textContent = 'Game ready to play!';
            startButton.disabled = false;
            startButton.classList.add('ready');
            windowContent.querySelector('.baddog-loading').style.display = 'none';
            clearInterval(loadingInterval);
        }
    }, 50);
    
    startButton.disabled = true;
    startButton.addEventListener('click', () => {
        startButton.textContent = 'Game in progress...';
        startButton.disabled = true;
        
        // Show "glitchy" behavior
        setTimeout(() => {
            startButton.textContent = 'Error loading game...';
            
            // Play error sound
            if (config.settings.soundEffects) {
                const errorSound = new Audio(config.settings.sounds.error);
                errorSound.play().catch(e => console.log("Audio playback failed:", e));
            }
            
            // Add glitch effect to the game area
            const gameArea = windowContent.querySelector('.game-area');
            gameArea.classList.add('glitching');
            
            // Show "corrupted" message
            setTimeout(() => {
                showCorruptedMessage(windowContent);
            }, 2000);
        }, 3000);
    });
}

function showCorruptedMessage(windowContent) {
    const gameArea = windowContent.querySelector('.game-area');
    gameArea.innerHTML = `
        <div class="corrupted-message">
            <p>ERROR: Game data corrupted</p>
            <p>File system error detected</p>
            <p class="baddog-reveal">BAD DOG VIRUS ACTIVATED</p>
        </div>
    `;
    
    // Play error sound
    if (config.settings.soundEffects) {
        const errorSound = new Audio(config.settings.sounds.error);
        errorSound.play().catch(e => console.log("Audio playback failed:", e));
    }
}

let infectionActive = true;
let infectedFileCount = 0;
const maxInfectedFiles = 15;
let infectionRate = 5000; // Start slow

function startFileInfection() {
    let infectionInterval = setInterval(() => {
        if (!infectionActive || infectedFileCount >= maxInfectedFiles) {
            clearInterval(infectionInterval);
            if (infectedFileCount >= maxInfectedFiles) {
                activateFullVirus();
            }
            return;
        }
        
        infectedFileCount++;
        createInfectedFile();
        
    }, infectionRate);
}

function accelerateInfection() {
    infectionRate = 2000; // Speed up infection
    
    // Create a small notification to show infection is spreading
    const notification = document.createElement('div');
    notification.className = 'baddog-notification';
    notification.textContent = 'System files being modified...';
    notification.style.position = 'fixed';
    notification.style.bottom = '50px';
    notification.style.right = '10px';
    notification.style.backgroundColor = 'rgba(255, 0, 0, 0.8)';
    notification.style.color = 'white';
    notification.style.padding = '5px 10px';
    notification.style.borderRadius = '3px';
    notification.style.zIndex = '99999';
    notification.style.fontSize = '12px';
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

function createInfectedFile() {
    // Create a fake file icon on the desktop to show infection
    const fileNames = [
        'system32.dll',
        'kernel.sys',
        'explorer.exe',
        'registry.dat',
        'config.ini',
        'bootmgr.exe',
        'shell32.dll',
        'ntuser.dat',
        'drivers.sys',
        'program.exe',
        'documents.db',
        'backup.bak',
        'windows.sys',
        'startup.cfg',
        'user.profile'
    ];
    
    const fileName = fileNames[infectedFileCount % fileNames.length];
    createDesktopIcon('baddog-file-' + infectedFileCount, fileName, 'infected-file-icon');
    
    // Occasionally play error sound
    if (infectedFileCount % 3 === 0 && config.settings.soundEffects) {
        const errorSound = new Audio(config.settings.sounds.error);
        errorSound.play().catch(e => console.log("Audio playback failed:", e));
    }
}

function activateFullVirus() {
    // If the browser has been used or system shut down
    // Check for conditions to fully activate the virus
    document.addEventListener('click', (e) => {
        if (e.target.closest('.google-button') || 
            e.target.closest('.start-item[data-action="shutdown"]')) {
            triggerVirusActivation();
        }
    });
    
    // Set a timer to activate anyway after some time
    setTimeout(() => {
        triggerVirusActivation();
    }, 60000); // 1 minute
}

function triggerVirusActivation() {
    if (!document.querySelector('.baddog-takeover-screen')) {
        createBadDogTakeoverScreen();
    }
}

function createBadDogTakeoverScreen() {
    // Create a full-screen takeover
    const takeoverScreen = document.createElement('div');
    takeoverScreen.className = 'baddog-takeover-screen';
    takeoverScreen.style.position = 'fixed';
    takeoverScreen.style.top = '0';
    takeoverScreen.style.left = '0';
    takeoverScreen.style.width = '100%';
    takeoverScreen.style.height = '100%';
    takeoverScreen.style.backgroundColor = 'black';
    takeoverScreen.style.color = '#8B4513';
    takeoverScreen.style.zIndex = '999999';
    takeoverScreen.style.display = 'flex';
    takeoverScreen.style.flexDirection = 'column';
    takeoverScreen.style.justifyContent = 'center';
    takeoverScreen.style.alignItems = 'center';
    takeoverScreen.style.fontFamily = 'monospace';
    
    takeoverScreen.innerHTML = `
        <div class="baddog-takeover-content">
            <div class="baddog-icon">
                <svg width="128" height="128" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10" fill="#8B4513" />
                    <circle cx="9" cy="9" r="1.5" fill="white" />
                    <circle cx="15" cy="9" r="1.5" fill="white" />
                    <path d="M7,13 C10,18 14,18 17,13" stroke="white" stroke-width="1.5" fill="none" />
                </svg>
            </div>
            <h1 class="baddog-title">BAD DOG VIRUS</h1>
            <div class="baddog-message">
                <p>Woof! Your computer has been infected!</p>
                <p>All your files have been chewed up by the Bad Dog Virus</p>
                <p>Your data is corrupted and your system will no longer function properly</p>
                <p class="baddog-hint">Next time, don't download "free" games!</p>
            </div>
            <div class="baddog-damage-meter">
                <div class="damage-label">DAMAGE PROGRESS:</div>
                <div class="damage-bar">
                    <div class="damage-fill"></div>
                </div>
            </div>
            <button class="baddog-restart">Restart Computer</button>
        </div>
    `;
    
    document.body.appendChild(takeoverScreen);
    
    // Animate the damage bar
    const damageFill = takeoverScreen.querySelector('.damage-fill');
    let damage = 0;
    
    const damageInterval = setInterval(() => {
        damage += 1;
        damageFill.style.width = damage + '%';
        
        if (damage >= 100) {
            clearInterval(damageInterval);
            showBadDogFinalScreen(takeoverScreen);
        }
        
        // Play frequent error sounds
        if (damage % 10 === 0 && config.settings.soundEffects) {
            const errorSound = new Audio(config.settings.sounds.error);
            errorSound.play().catch(e => console.log("Audio playback failed:", e));
        }
    }, 200);
    
    // Set up restart button
    const restartButton = takeoverScreen.querySelector('.baddog-restart');
    restartButton.addEventListener('click', () => {
        location.reload();
    });
    
    // Create barking dogs at random positions
    createRandomDogs(takeoverScreen);
}

function createRandomDogs(parentElement) {
    for (let i = 0; i < 10; i++) {
        setTimeout(() => {
            const dog = document.createElement('div');
            dog.className = 'baddog-random';
            dog.style.position = 'absolute';
            dog.style.top = Math.random() * 100 + '%';
            dog.style.left = Math.random() * 100 + '%';
            dog.style.transform = 'translate(-50%, -50%)';
            
            dog.innerHTML = `
                <svg width="32" height="32" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10" fill="#8B4513" />
                    <circle cx="9" cy="9" r="1.5" fill="white" />
                    <circle cx="15" cy="9" r="1.5" fill="white" />
                    <path d="M7,13 C10,18 14,18 17,13" stroke="white" stroke-width="1.5" fill="none" />
                </svg>
            `;
            
            parentElement.appendChild(dog);
            
            // Play bark sound
            if (config.settings.soundEffects) {
                const errorSound = new Audio(config.settings.sounds.error);
                errorSound.volume = 0.3;
                errorSound.play().catch(e => console.log("Audio playback failed:", e));
            }
            
            // Animate the dog
            let posX = parseFloat(dog.style.left);
            let posY = parseFloat(dog.style.top);
            let dirX = Math.random() > 0.5 ? 1 : -1;
            let dirY = Math.random() > 0.5 ? 1 : -1;
            
            const moveInterval = setInterval(() => {
                posX += dirX * 0.5;
                posY += dirY * 0.5;
                
                if (posX < 0 || posX > 100) dirX *= -1;
                if (posY < 0 || posY > 100) dirY *= -1;
                
                dog.style.left = posX + '%';
                dog.style.top = posY + '%';
            }, 50);
            
            // Clean up after some time
            setTimeout(() => {
                clearInterval(moveInterval);
                dog.remove();
            }, 10000);
        }, i * 1000);
    }
}

function showBadDogFinalScreen(takeoverScreen) {
    takeoverScreen.innerHTML = `
        <div class="baddog-final-screen">
            <h1>SYSTEM CORRUPTED</h1>
            <p>Your computer is now a dog house!</p>
            <pre class="ascii-art">
               __
              /  \\
             /    \\
            /      \\
           /        \\
          /          \\
         /            \\
        /              \\
       /________________\\
      /|                |\\
       |   BAD DOG WAS  |
       |     HERE!      |
       |________________|
       |                |
       |     ______     |
       |    |      |    |
       |____|      |____|
    </pre>
            <button class="baddog-restart">Restart Computer</button>
        </div>
    `;
    
    // Set up restart button
    const restartButton = takeoverScreen.querySelector('.baddog-restart');
    restartButton.addEventListener('click', () => {
        location.reload();
    });
    
    // Play multiple error sounds
    if (config.settings.soundEffects) {
        for (let i = 0; i < 5; i++) {
            setTimeout(() => {
                const errorSound = new Audio(config.settings.sounds.error);
                errorSound.play().catch(e => console.log("Audio playback failed:", e));
            }, i * 500);
        }
    }
}

function makeWindowDraggable(window, handle) {
    let isDragging = false;
    let offsetX, offsetY;
    
    handle.addEventListener('mousedown', (e) => {
        if (e.target.classList.contains('window-button')) return;
        
        isDragging = true;
        
        const rect = window.getBoundingClientRect();
        offsetX = e.clientX - rect.left;
        offsetY = e.clientY - rect.top;
    });
    
    document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        
        const left = e.clientX - offsetX;
        const top = e.clientY - offsetY;
        
        window.style.left = left + 'px';
        window.style.top = top + 'px';
    });
    
    document.addEventListener('mouseup', () => {
        isDragging = false;
    });
}

function createTaskbarItem(window) {
    const taskItems = document.querySelector('.task-items');
    
    const taskItem = document.createElement('div');
    taskItem.className = 'task-item active';
    
    const iconImg = document.createElement('div');
    iconImg.className = 'icon-img baddog-icon';
    
    const label = document.createElement('span');
    label.textContent = 'Bad Dog Game';
    
    taskItem.appendChild(iconImg);
    taskItem.appendChild(label);
    
    taskItem.addEventListener('click', () => {
        if (window.style.display === 'none') {
            window.style.display = 'flex';
            taskItem.classList.add('active');
        } else {
            window.style.display = 'none';
            taskItem.classList.remove('active');
        }
    });
    
    taskItems.appendChild(taskItem);
    window.taskItem = taskItem;
}