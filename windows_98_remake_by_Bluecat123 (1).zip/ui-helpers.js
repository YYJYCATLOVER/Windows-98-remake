// UI helper functions extracted from script.js
import * as config from 'config';

export function createAboutContent(container) {
    container.classList.add('about-content');
    
    const logo = document.createElement('div');
    logo.className = 'about-logo';
    logo.textContent = 'Windows 98 Remake';
    container.appendChild(logo);
    
    const info = document.createElement('div');
    info.className = 'about-info';
    info.innerHTML = `
        <p>Windows 98 Remake - A Windows 98 style interface</p>
        <p>Version 1.0</p>
        <p>  ${new Date().getFullYear()}</p>
    `;
    container.appendChild(info);
    
    const button = document.createElement('button');
    button.className = 'about-button';
    button.textContent = 'OK';
    button.addEventListener('click', () => {
        const window = container.closest('.window');
        window.remove(); 
    });
    container.appendChild(button);
}

// Add other UI creation functions as needed