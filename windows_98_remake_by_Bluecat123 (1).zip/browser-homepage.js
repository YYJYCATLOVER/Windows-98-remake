// New file for managing browser homepage and bookmarks
import { loadWebsite } from './website-loader.js';

export function createBrowserHomepage(container) {
    const content = container.querySelector('.website-browser');
    
    content.innerHTML = `
        <div class="browser-homepage">
            <div class="browser-logo">
                <img src="chromeICON.png" alt="Internet Explorer" width="64" height="64">
                <h1>Internet Explorer</h1>
            </div>
            
            <div class="search-bar">
                <input type="text" placeholder="Search the web or enter address">
                <button>Go</button>
            </div>
            
            <div class="bookmarks">
                <h2>Popular Websites</h2>
                <div class="bookmark-grid">
                    <div class="bookmark" data-url="google.com">
                        <img src="google.jpg" alt="Google" width="32" height="32">
                        <span>Google</span>
                    </div>
                    <div class="bookmark" data-url="spykitty.com">
                        <svg width="32" height="32" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="10" fill="#00aa00" />
                            <path d="M7,12 L11,16 L17,9" stroke="white" stroke-width="2" fill="none" />
                            <path d="M8,7 C10,5 14,5 16,7" stroke="white" stroke-width="1.5" fill="none" />
                            <circle cx="9" cy="9" r="1" fill="white" />
                            <circle cx="15" cy="9" r="1" fill="white" />
                        </svg>
                        <span>SpyKitty Antivirus</span>
                    </div>
                    <div class="bookmark" data-url="butterflydownload.com">
                        <img src="Butterfly.png" alt="Butterfly" width="32" height="32">
                        <span>Butterfly Download</span>
                    </div>
                    <div class="bookmark" data-url="aboutvirus.com">
                        <svg width="32" height="32" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="10" fill="#ff6666" />
                            <path d="M12,7 L12,15" stroke="white" stroke-width="2" />
                            <circle cx="12" cy="18" r="1" fill="white" />
                        </svg>
                        <span>About Viruses</span>
                    </div>
                    <div class="bookmark" data-url="wincatvirus.com">
                        <svg width="32" height="32" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="10" fill="#ff2222" />
                            <path d="M8,12 C8,9 12,6 16,9" stroke="white" stroke-width="1.5" fill="none" />
                            <path d="M8,12 C8,15 12,18 16,15" stroke="white" stroke-width="1.5" fill="none" />
                            <circle cx="9" cy="9" r="1" fill="white" />
                            <circle cx="9" cy="15" r="1" fill="white" />
                        </svg>
                        <span>WINCAT Virus</span>
                    </div>
                    <div class="bookmark" data-url="wincatclean.com">
                        <svg width="32" height="32" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="10" fill="#00aaff" />
                            <path d="M8,12 C8,9 12,6 16,9" stroke="white" stroke-width="1.5" fill="none" />
                            <path d="M8,12 C8,15 12,18 16,15" stroke="white" stroke-width="1.5" fill="none" />
                            <circle cx="9" cy="9" r="1" fill="white" />
                            <circle cx="9" cy="15" r="1" fill="white" />
                        </svg>
                        <span>WINCATclean</span>
                    </div>
                    <div class="bookmark" data-url="freeganenovirus.com">
                        <svg width="32" height="32" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="10" fill="#333" />
                            <path d="M8,12 C8,9 12,7 16,9" stroke="#f55" stroke-width="1.5" fill="none" />
                            <path d="M8,12 C8,15 12,17 16,15" stroke="#f55" stroke-width="1.5" fill="none" />
                            <circle cx="9" cy="9" r="1" fill="#f55" />
                            <circle cx="9" cy="15" r="1" fill="#f55" />
                        </svg>
                        <span>Free Games</span>
                    </div>
                    <div class="bookmark" data-url="iloveyou.com">
                        <svg width="32" height="32" viewBox="0 0 24 24">
                            <path fill="#ff0000" d="M12,21.35L10.55,20.03C5.4,15.36 2,12.27 2,8.5C2,5.41 4.42,3 7.5,3C9.24,3 10.91,3.81 12,5.08C13.09,3.81 14.76,3 16.5,3C19.58,3 22,5.41 22,8.5C22,12.27 18.6,15.36 13.45,20.03L12,21.35Z"/>
                        </svg>
                        <span>ILOVEYOU</span>
                    </div>
                    <div class="bookmark" data-url="baddoggamedownloader.com">
                        <svg width="32" height="32" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="10" fill="#8B4513" />
                            <circle cx="9" cy="9" r="1.5" fill="white" />
                            <circle cx="15" cy="9" r="1.5" fill="white" />
                            <path d="M8,13 C10,16 14,16 16,13" stroke="white" stroke-width="1.5" fill="none" />
                        </svg>
                        <span>Bad Dog Game</span>
                    </div>
                </div>
            </div>
            
            <div class="site-info">
                <p>${new Date().getFullYear()} Internet Explorer - Windows 98 Edition</p>
            </div>
        </div>
    `;
    
    // Add click handlers for bookmarks
    const bookmarks = content.querySelectorAll('.bookmark');
    bookmarks.forEach(bookmark => {
        bookmark.addEventListener('click', () => {
            const url = bookmark.dataset.url;
            const browserWindow = container.closest('.window');
            if (browserWindow) {
                const addressBar = browserWindow.querySelector('.google-address');
                if (addressBar) {
                    addressBar.value = url;
                    loadWebsite(container, url);
                }
            }
        });
    });
    
    // Add functionality to search bar
    const searchInput = content.querySelector('.search-bar input');
    const searchButton = content.querySelector('.search-bar button');
    
    searchButton.addEventListener('click', () => {
        if (searchInput.value.trim()) {
            loadWebsite(container, searchInput.value);
        }
    });
    
    searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && searchInput.value.trim()) {
            loadWebsite(container, searchInput.value);
        }
    });
}