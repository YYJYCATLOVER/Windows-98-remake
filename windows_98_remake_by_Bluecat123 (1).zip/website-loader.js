// New file for website loading functionality
import { createButterflyWebsite } from './butterfly-virus.js';
import { createSpyKittyWebsite } from './spykitty-app.js';
import { showDownloadNotification, createDesktopIcon, desktopIconExists } from './desktop-manager.js';
import * as config from 'config';

export function loadWebsite(container, url) {
    const content = container.querySelector('.website-browser');
    
    // Handle empty or missing URL
    if (!url || url.trim() === '') {
        // Show homepage when no URL is provided
        import('./browser-homepage.js').then(module => {
            module.createBrowserHomepage(container);
        });
        return;
    }
    
    const cleanUrl = url.toLowerCase().trim();
    
    if (cleanUrl === 'iloveyou.com' || cleanUrl === 'www.iloveyou.com' || 
        cleanUrl === 'http://iloveyou.com' || cleanUrl === 'https://iloveyou.com') {
        // Show ILOVEYOU.com website
        showILoveYouWebsite(content);
    } else if (cleanUrl === 'google.com' || cleanUrl === 'www.google.com' || 
              cleanUrl === 'http://google.com' || cleanUrl === 'https://google.com') {
        // Show Google website
        showGoogleWebsite(content);
    } else if (cleanUrl === 'butterflydownload.com' || cleanUrl === 'www.butterflydownload.com' || 
              cleanUrl === 'http://butterflydownload.com' || cleanUrl === 'https://butterflydownload.com') {
        // Show butterfly download website
        createButterflyWebsite(content);
    } else if (cleanUrl === 'spykitty.com' || cleanUrl === 'www.spykitty.com' || 
              cleanUrl === 'http://spykitty.com' || cleanUrl === 'https://spykitty.com') {
        // Show SpyKitty website
        createSpyKittyWebsite(content);
    } else if (cleanUrl === 'aboutvirus.com' || cleanUrl === 'www.aboutvirus.com' || 
              cleanUrl === 'http://aboutvirus.com' || cleanUrl === 'https://aboutvirus.com') {
        // Show AboutVirus website
        import('./about-virus.js').then(module => {
            module.createAboutVirusWebsite(content);
        });
    } else if (cleanUrl === 'wincatvirus.com' || cleanUrl === 'www.wincatvirus.com' || 
              cleanUrl === 'http://wincatvirus.com' || cleanUrl === 'https://wincatvirus.com') {
        // Show WINCAT virus website
        import('./wincat-virus.js').then(module => {
            module.createWincatWebsite(content);
        });
    } else if (cleanUrl === 'wincatclean.com' || cleanUrl === 'www.wincatclean.com' || 
              cleanUrl === 'http://wincatclean.com' || cleanUrl === 'https://wincatclean.com') {
        // Show WINCAT clean website
        import('./wincat-clean.js').then(module => {
            module.createWincatCleanWebsite(content);
        });
    } else if (cleanUrl === 'freeganenovirus.com' || cleanUrl === 'www.freeganenovirus.com' || 
              cleanUrl === 'http://freeganenovirus.com' || cleanUrl === 'https://freeganenovirus.com') {
        // Show Free Game No Virus website
        import('./lockcat-virus.js').then(module => {
            module.createFreeGameWebsite(content);
        });
    } else if (cleanUrl === 'baddoggamedownloader.com' || cleanUrl === 'www.baddoggamedownloader.com' || 
              cleanUrl === 'http://baddoggamedownloader.com' || cleanUrl === 'https://baddoggamedownloader.com') {
        // Show BadDog game downloader website
        import('./baddog-virus.js').then(module => {
            module.createBadDogWebsite(content);
        });
    } else {
        // Show homepage instead of 404
        import('./browser-homepage.js').then(module => {
            module.createBrowserHomepage(container);
        });
    }
}

function showGoogleWebsite(content) {
    // Google Beta logo and search
    content.innerHTML = `
        <div class="google-search-container">
            <img src="google.jpg" alt="Google Beta" class="google-logo">
            <div class="google-search">
                <input type="text" class="google-search-input" placeholder="Search the web using Google!">
                <div class="google-buttons">
                    <button>Google Search</button>
                    <button>I'm Feeling Lucky</button>
                </div>
            </div>
            <div class="google-footer">
                <p>Copyright 1998 Google Inc.</p>
            </div>
        </div>
    `;
}

function showILoveYouWebsite(content) {
    content.innerHTML = `
        <div class="iloveyou-website">
            <h1>Welcome to I Love You!</h1>
            <p>Share your love with friends and family!</p>
            <p>Download our special program to spread the love!</p>
            <div class="download-section">
                <div class="download-icon">
                    <svg width="48" height="48" viewBox="0 0 24 24">
                        <path fill="#ff0000" d="M12,2 L4,10 L9,10 L9,16 L15,16 L15,10 L20,10 L12,2 Z M5,18 L19,18 L19,20 L5,20 L5,18 Z"/>
                    </svg>
                </div>
                <button class="download-button">DOWNLOAD ILOVEYOU.EXE</button>
            </div>
        </div>
    `;
    
    // Add click event for download button
    const downloadButton = content.querySelector('.download-button');
    downloadButton.addEventListener('click', () => {
        if (!desktopIconExists('iloveyou')) {
            showDownloadNotification('iloveyou', 'Download Complete', executeVirus, 'virus-icon');
        } else {
            alert('ILOVEYOU.EXE is already downloaded.');
        }
    });
}

function showDownloadedFile() {
    createDesktopIcon('iloveyou', 'ILOVEYOU.EXE', 'virus-icon');
}

function executeVirus() {
    // Show the virus message
    const dialog = document.createElement('div');
    dialog.className = 'dialog virus-dialog';
    
    const header = document.createElement('div');
    header.className = 'dialog-header';
    
    const icon = document.createElement('div');
    icon.className = 'dialog-icon';
    icon.style.backgroundImage = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle fill='%23ff0000' cx='16' cy='16' r='14'/%3E%3Cpath fill='%23ffffff' d='M14 8h4v12h-4zM14 22h4v4h-4z'/%3E%3C/svg%3E\")";
    
    const title = document.createElement('div');
    title.className = 'dialog-title';
    title.textContent = 'ILOVEYOU';
    
    header.appendChild(icon);
    header.appendChild(title);
    dialog.appendChild(header);
    
    const content = document.createElement('div');
    content.className = 'dialog-content';
    content.innerHTML = 'I love you!<br><br>BTW it\'s a WORM and starts to duplicate itself!';
    dialog.appendChild(content);
    
    const buttons = document.createElement('div');
    buttons.className = 'dialog-buttons';
    
    const okButton = document.createElement('button');
    okButton.className = 'dialog-button';
    okButton.textContent = 'OK';
    okButton.addEventListener('click', () => {
        dialog.remove();
        startVirusReplication();
    });
    
    buttons.appendChild(okButton);
    dialog.appendChild(buttons);
    
    document.body.appendChild(dialog);
    
    // Play error sound
    if (config.settings.soundEffects) {
        const errorSound = new Audio(config.settings.sounds.error);
        errorSound.play().catch(e => console.log("Audio playback failed:", e));
    }
}

// Function to start virus replication
function startVirusReplication() {
    let replicationCount = 0;
    
    function replicateVirus() {
        if (replicationCount >= config.settings.virus.replicationLimit) {
            showSystemCrashDialog();
            return;
        }
        
        const virusWindow = document.createElement('div');
        virusWindow.className = 'window virus-window';
        virusWindow.style.left = Math.random() * (window.innerWidth - 300) + 'px';
        virusWindow.style.top = Math.random() * (window.innerHeight - 200) + 'px';
        virusWindow.style.width = '250px';
        virusWindow.style.height = '150px';
        virusWindow.style.zIndex = 9999;
        
        const windowHeader = document.createElement('div');
        windowHeader.className = 'window-header';
        
        const windowTitle = document.createElement('div');
        windowTitle.className = 'window-title';
        windowTitle.textContent = 'ILOVEYOU - ' + (replicationCount + 1);
        windowHeader.appendChild(windowTitle);
        
        const windowControls = document.createElement('div');
        windowControls.className = 'window-controls';
        
        const closeButton = document.createElement('div');
        closeButton.className = 'window-button close';
        closeButton.innerHTML = 'x';
        closeButton.addEventListener('click', (e) => {
            e.stopPropagation();
            virusWindow.remove();
        });
        
        windowControls.appendChild(closeButton);
        windowHeader.appendChild(windowControls);
        virusWindow.appendChild(windowHeader);
        
        const windowContent = document.createElement('div');
        windowContent.className = 'window-content virus-content';
        windowContent.innerHTML = '<div class="virus-message">I LOVE YOU!</div>';
        virusWindow.appendChild(windowContent);
        
        document.getElementById('windows-container').appendChild(virusWindow);
        
        // Play error sound with each replication
        if (config.settings.soundEffects) {
            const errorSound = new Audio(config.settings.sounds.error);
            errorSound.play().catch(e => console.log("Audio playback failed:", e));
        }
        
        replicationCount++;
        setTimeout(replicateVirus, config.settings.virus.replicationDelay);
    }
    
    replicateVirus();
}

function showSystemCrashDialog() {
    const dialog = document.createElement('div');
    dialog.className = 'dialog system-crash';
    
    const header = document.createElement('div');
    header.className = 'dialog-header';
    header.style.backgroundColor = '#0000aa';
    
    const title = document.createElement('div');
    title.className = 'dialog-title';
    title.textContent = 'SYSTEM ERROR';
    
    header.appendChild(title);
    dialog.appendChild(header);
    
    const content = document.createElement('div');
    content.className = 'dialog-content bsod-content';
    content.innerHTML = `
        <p>A fatal exception has occurred at 0028:C0011E36 in VXD VMM(01) + 
        00010E36. The current application will be terminated.</p>
        
        <p>* Press any key to terminate the current application</p>
        <p>* Press CTRL+ALT+DEL to restart your computer</p>
    `;
    dialog.appendChild(content);
    
    const fullScreenDiv = document.createElement('div');
    fullScreenDiv.className = 'bsod-overlay';
    fullScreenDiv.appendChild(dialog);
    
    document.body.appendChild(fullScreenDiv);
    
    fullScreenDiv.addEventListener('click', () => {
        location.reload();
    });
    
    document.addEventListener('keydown', () => {
        location.reload();
    }, { once: true });
}