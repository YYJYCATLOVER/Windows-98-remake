// WINCATclean module - a safe, non-destructive version of WINCAT virus for educational purposes
import * as config from 'config';
import { showDownloadNotification, createDesktopIcon, desktopIconExists } from './desktop-manager.js';

export function createWincatCleanWebsite(content) {
    content.innerHTML = `
        <div class="wincat-clean-website">
            <h1>WINCATclean - Educational Version</h1>
            <p>This is a safe version of the WINCAT virus - for educational purposes only.</p>
            <p>Experience the effects of WINCAT without any actual damage to your system.</p>
            <div class="download-section">
                <div class="download-icon">
                    <svg width="64" height="64" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10" fill="#00aaff" />
                        <path d="M8,12 C8,9 12,6 16,9" stroke="white" stroke-width="1.5" fill="none" />
                        <path d="M8,12 C8,15 12,18 16,15" stroke="white" stroke-width="1.5" fill="none" />
                        <circle cx="9" cy="9" r="1" fill="white" />
                        <circle cx="9" cy="15" r="1" fill="white" />
                    </svg>
                </div>
                <button class="download-button">DOWNLOAD WINCATCLEAN.EXE</button>
            </div>
        </div>
    `;
    
    // Add click event for download button
    const downloadButton = content.querySelector('.download-button');
    downloadButton.addEventListener('click', () => {
        if (!desktopIconExists('wincatclean')) {
            showDownloadNotification('wincatclean', 'Download Complete', executeWincatClean, 'wincatclean-icon');
        } else {
            alert('WINCATCLEAN.EXE is already downloaded.');
        }
    });
}

function executeWincatClean() {
    const cleanWindow = document.createElement('div');
    cleanWindow.className = 'window';
    cleanWindow.dataset.app = 'wincatclean';
    cleanWindow.style.width = '500px';
    cleanWindow.style.height = '380px';
    cleanWindow.style.left = '50%';
    cleanWindow.style.top = '50%';
    cleanWindow.style.transform = 'translate(-50%, -50%)';
    cleanWindow.style.zIndex = '10000';
    
    const windowHeader = document.createElement('div');
    windowHeader.className = 'window-header';
    
    const windowTitle = document.createElement('div');
    windowTitle.className = 'window-title';
    windowTitle.textContent = 'WINCATclean Simulator';
    
    windowHeader.appendChild(windowTitle);
    
    const windowControls = document.createElement('div');
    windowControls.className = 'window-controls';
    
    const minimizeButton = document.createElement('div');
    minimizeButton.className = 'window-button minimize';
    minimizeButton.innerHTML = '_';
    minimizeButton.addEventListener('click', () => {
        cleanWindow.style.display = 'none';
        if (cleanWindow.taskItem) {
            cleanWindow.taskItem.classList.remove('active');
        }
    });
    
    const fullscreenButton = document.createElement('div');
    fullscreenButton.className = 'window-button fullscreen';
    fullscreenButton.innerHTML = '□';
    
    const closeButton = document.createElement('div');
    closeButton.className = 'window-button close';
    closeButton.innerHTML = 'x';
    closeButton.addEventListener('click', () => {
        cleanWindow.remove();
        if (cleanWindow.taskItem) {
            cleanWindow.taskItem.remove();
        }
    });
    
    windowControls.appendChild(minimizeButton);
    windowControls.appendChild(fullscreenButton);
    windowControls.appendChild(closeButton);
    windowHeader.appendChild(windowControls);
    cleanWindow.appendChild(windowHeader);
    
    const windowContent = document.createElement('div');
    windowContent.className = 'window-content';
    
    windowContent.innerHTML = `
        <div class="wincat-clean-content">
            <div class="wincat-clean-header">
                <div class="wincat-clean-logo">
                    <svg width="48" height="48" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10" fill="#00aaff" />
                        <path d="M8,12 C8,9 12,6 16,9" stroke="white" stroke-width="1.5" fill="none" />
                        <path d="M8,12 C8,15 12,18 16,15" stroke="white" stroke-width="1.5" fill="none" />
                        <circle cx="9" cy="9" r="1" fill="white" />
                        <circle cx="9" cy="15" r="1" fill="white" />
                    </svg>
                </div>
                <div class="wincat-clean-title">
                    <h2>WINCATclean Simulator</h2>
                    <p>Safely experience WINCAT virus effects</p>
                </div>
            </div>
            
            <div class="wincat-clean-warning">
                <p>⚠️ The real WINCAT virus is extremely dangerous and can permanently damage your computer's BIOS.</p>
                <p>This simulator lets you experience its effects safely for educational purposes.</p>
            </div>
            
            <div class="wincat-clean-buttons">
                <h3>WINCAT Effects</h3>
                <p>Click buttons to simulate different WINCAT effects:</p>
                
                <div class="button-grid">
                    <button class="effect-button" id="web-windows">Open Web Windows</button>
                    <button class="effect-button" id="open-apps">Launch Random Apps</button>
                    <button class="effect-button" id="change-colors">Flash Colors</button>
                    <button class="effect-button" id="screen-duplicate">Screen Duplication</button>
                    <button class="effect-button" id="error-popups">Error Popups</button>
                    <button class="effect-button" id="fake-bios">Fake BIOS Death</button>
                    <button class="effect-button" id="nyan-cat">Nyan Cat</button>
                    <button class="effect-button" id="stop-all">Stop All Effects</button>
                </div>
            </div>
            
            <div class="wincat-clean-footer">
                <p>Created for educational purposes only.</p>
                <p>Learn about malware to better protect yourself.</p>
            </div>
        </div>
    `;
    
    cleanWindow.appendChild(windowContent);
    document.getElementById('windows-container').appendChild(cleanWindow);
    
    // Register in taskbar
    makeWindowDraggable(cleanWindow, windowHeader);
    createTaskbarItem(cleanWindow);
    
    // Set up effect buttons
    setupEffectButtons(cleanWindow);
}

function setupEffectButtons(cleanWindow) {
    const webWindowsBtn = cleanWindow.querySelector('#web-windows');
    const openAppsBtn = cleanWindow.querySelector('#open-apps');
    const changeColorsBtn = cleanWindow.querySelector('#change-colors');
    const screenDuplicateBtn = cleanWindow.querySelector('#screen-duplicate');
    const errorPopupsBtn = cleanWindow.querySelector('#error-popups');
    const fakeBiosBtn = cleanWindow.querySelector('#fake-bios');
    const nyanCatBtn = cleanWindow.querySelector('#nyan-cat');
    const stopAllBtn = cleanWindow.querySelector('#stop-all');
    
    // Store intervals and elements for cleanup
    const effects = {
        webWindows: null,
        openApps: null,
        colors: null,
        screenDuplication: null,
        errorPopups: null,
        biosScreen: null,
        nyanCat: null
    };
    
    // Web Windows effect
    webWindowsBtn.addEventListener('click', () => {
        stopEffect('webWindows');
        
        const websites = [
            'https://google.com',
            'https://spykitty.com',
            'https://butterflydownload.com',
            'https://aboutvirus.com'
        ];
        
        let count = 0;
        effects.webWindows = setInterval(() => {
            if (count >= 3) {
                clearInterval(effects.webWindows);
                return;
            }
            
            createFakeWindow('Internet Explorer', websites[Math.floor(Math.random() * websites.length)]);
            count++;
            
            playErrorSound();
        }, 2000);
    });
    
    // Open Apps effect
    openAppsBtn.addEventListener('click', () => {
        stopEffect('openApps');
        
        const apps = ['notepad', 'minesweeper', 'explorer', 'about'];
        
        let count = 0;
        effects.openApps = setInterval(() => {
            if (count >= 3) {
                clearInterval(effects.openApps);
                return;
            }
            
            createFakeWindow(getAppTitle(apps[Math.floor(Math.random() * apps.length)]));
            count++;
            
            playErrorSound();
        }, 2000);
    });
    
    // Change Colors effect
    changeColorsBtn.addEventListener('click', () => {
        stopEffect('colors');
        
        const originalColor = document.body.style.backgroundColor;
        const colors = ['#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF'];
        let colorIndex = 0;
        
        effects.colors = setInterval(() => {
            document.body.style.backgroundColor = colors[colorIndex % colors.length];
            colorIndex++;
            
            playErrorSound();
        }, 1000);
        
        // Auto-stop after 5 seconds
        setTimeout(() => {
            stopEffect('colors');
            document.body.style.backgroundColor = originalColor;
        }, 5000);
    });
    
    // Screen Duplication effect
    screenDuplicateBtn.addEventListener('click', () => {
        stopEffect('screenDuplication');
        
        // Create container for duplication effect
        const duplicationContainer = document.createElement('div');
        duplicationContainer.className = 'wincat-duplication-container';
        duplicationContainer.style.position = 'fixed';
        duplicationContainer.style.top = '0';
        duplicationContainer.style.left = '0';
        duplicationContainer.style.width = '100%';
        duplicationContainer.style.height = '100%';
        duplicationContainer.style.pointerEvents = 'none';
        duplicationContainer.style.zIndex = '9998';
        
        document.body.appendChild(duplicationContainer);
        effects.screenDuplication = duplicationContainer;
        
        // Create fake screenshots
        let scale = 0.9;
        
        for (let i = 0; i < 5; i++) {
            setTimeout(() => {
                scale *= 0.9;
                
                const fakeScreenshot = document.createElement('div');
                fakeScreenshot.className = 'wincat-screenshot';
                fakeScreenshot.style.position = 'absolute';
                fakeScreenshot.style.width = (scale * 100) + '%';
                fakeScreenshot.style.height = (scale * 100) + '%';
                fakeScreenshot.style.top = ((1 - scale) / 2 * 100) + '%';
                fakeScreenshot.style.left = ((1 - scale) / 2 * 100) + '%';
                fakeScreenshot.style.border = '2px solid #000';
                fakeScreenshot.style.backgroundColor = '#c0c0c0';
                fakeScreenshot.style.opacity = '0.8';
                fakeScreenshot.style.zIndex = '10000';
                
                duplicationContainer.appendChild(fakeScreenshot);
                
                playErrorSound();
            }, i * 1000);
        }
        
        // Auto-cleanup after 6 seconds
        setTimeout(() => {
            stopEffect('screenDuplication');
        }, 6000);
    });
    
    // Error Popups effect
    errorPopupsBtn.addEventListener('click', () => {
        stopEffect('errorPopups');
        
        let count = 0;
        effects.errorPopups = setInterval(() => {
            if (count >= 3) {
                clearInterval(effects.errorPopups);
                return;
            }
            
            createErrorPopup('System Warning', 'This is a simulated WINCAT error');
            count++;
            
            playErrorSound();
        }, 1500);
    });
    
    // Fake BIOS Death effect
    fakeBiosBtn.addEventListener('click', () => {
        stopEffect('biosScreen');
        
        const biosScreen = document.createElement('div');
        biosScreen.className = 'fake-bios-screen';
        biosScreen.style.position = 'fixed';
        biosScreen.style.top = '0';
        biosScreen.style.left = '0';
        biosScreen.style.width = '100%';
        biosScreen.style.height = '100%';
        biosScreen.style.backgroundColor = 'black';
        biosScreen.style.color = 'red';
        biosScreen.style.fontFamily = 'monospace';
        biosScreen.style.padding = '50px';
        biosScreen.style.zIndex = '99999';
        biosScreen.style.display = 'flex';
        biosScreen.style.flexDirection = 'column';
        biosScreen.style.justifyContent = 'center';
        biosScreen.style.alignItems = 'center';
        
        biosScreen.innerHTML = `
            <div style="margin-bottom: 20px;">
                <h1 style="color: red; font-size: 32px; text-align: center;">SIMULATED BIOS ERROR</h1>
                <p style="color: red; font-size: 20px; text-align: center;">This is what WINCAT would do to your BIOS</p>
            </div>
            <div style="margin-bottom: 20px; text-align: left; width: 80%;">
                <p>In a real WINCAT attack, your BIOS would be corrupted</p>
                <p>SIMULATION MODE - No actual damage is being done</p>
                <p>Your computer is safe</p>
            </div>
            <button id="close-bios" style="padding: 10px; margin-top: 20px;">Close Simulation</button>
        `;
        
        document.body.appendChild(biosScreen);
        effects.biosScreen = biosScreen;
        
        const closeButton = biosScreen.querySelector('#close-bios');
        closeButton.addEventListener('click', () => {
            stopEffect('biosScreen');
        });
        
        playErrorSound();
    });
    
    // Nyan Cat effect
    nyanCatBtn.addEventListener('click', () => {
        stopEffect('nyanCat');
        
        const nyanContainer = document.createElement('div');
        nyanContainer.className = 'nyan-container';
        nyanContainer.style.position = 'fixed';
        nyanContainer.style.top = '0';
        nyanContainer.style.left = '0';
        nyanContainer.style.width = '100%';
        nyanContainer.style.height = '100%';
        nyanContainer.style.backgroundColor = 'rgba(0,0,0,0.8)';
        nyanContainer.style.zIndex = '99999';
        nyanContainer.style.display = 'flex';
        nyanContainer.style.flexDirection = 'column';
        nyanContainer.style.justifyContent = 'center';
        nyanContainer.style.alignItems = 'center';
        
        nyanContainer.innerHTML = `
            <h2 style="color: white; margin-bottom: 20px;">Nyan Cat Simulation</h2>
            <iframe width="480" height="360" src="https://www.nyan.cat/" frameborder="0"></iframe>
            <button id="close-nyan" style="padding: 10px; margin-top: 20px;">Close Nyan Cat</button>
        `;
        
        document.body.appendChild(nyanContainer);
        effects.nyanCat = nyanContainer;
        
        const closeButton = nyanContainer.querySelector('#close-nyan');
        closeButton.addEventListener('click', () => {
            stopEffect('nyanCat');
        });
    });
    
    // Stop All effects
    stopAllBtn.addEventListener('click', () => {
        for (const effect in effects) {
            stopEffect(effect);
        }
        document.body.style.backgroundColor = '';
    });
    
    function stopEffect(effectName) {
        if (effects[effectName]) {
            if (typeof effects[effectName] === 'number') {
                clearInterval(effects[effectName]);
            } else if (effects[effectName] instanceof Element) {
                effects[effectName].remove();
            }
            effects[effectName] = null;
        }
    }
    
    function createFakeWindow(title, url) {
        const fakeWindow = document.createElement('div');
        fakeWindow.className = 'window fake-window';
        fakeWindow.style.width = '300px';
        fakeWindow.style.height = '200px';
        fakeWindow.style.left = (100 + Math.random() * 300) + 'px';
        fakeWindow.style.top = (50 + Math.random() * 200) + 'px';
        fakeWindow.style.zIndex = '9997';
        
        const windowHeader = document.createElement('div');
        windowHeader.className = 'window-header';
        
        const windowTitle = document.createElement('div');
        windowTitle.className = 'window-title';
        windowTitle.textContent = title || 'Window';
        
        windowHeader.appendChild(windowTitle);
        
        const windowControls = document.createElement('div');
        windowControls.className = 'window-controls';
        
        const closeButton = document.createElement('div');
        closeButton.className = 'window-button close';
        closeButton.innerHTML = 'x';
        closeButton.addEventListener('click', () => {
            fakeWindow.remove();
        });
        
        windowControls.appendChild(closeButton);
        windowHeader.appendChild(windowControls);
        fakeWindow.appendChild(windowHeader);
        
        const windowContent = document.createElement('div');
        windowContent.className = 'window-content';
        windowContent.innerHTML = `
            <div style="padding: 20px; text-align: center;">
                <h3>This is a simulated window</h3>
                <p>${url ? 'Fake URL: ' + url : 'Simulated WINCAT effect'}</p>
                <p style="font-size: 12px; margin-top: 15px;">This window is harmless</p>
            </div>
        `;
        
        fakeWindow.appendChild(windowContent);
        
        document.getElementById('windows-container').appendChild(fakeWindow);
        
        // Make draggable
        makeWindowDraggable(fakeWindow, windowHeader);
        
        return fakeWindow;
    }
    
    function createErrorPopup(title, message) {
        const dialog = document.createElement('div');
        dialog.className = 'dialog';
        dialog.style.left = (50 + Math.random() * 400) + 'px';
        dialog.style.top = (50 + Math.random() * 300) + 'px';
        dialog.style.transform = 'none';
        
        const header = document.createElement('div');
        header.className = 'dialog-header';
        
        const icon = document.createElement('div');
        icon.className = 'dialog-icon';
        icon.style.backgroundImage = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle fill='%23ff0000' cx='16' cy='16' r='14'/%3E%3Cpath fill='%23ffffff' d='M14 8h4v12h-4zM14 22h4v4h-4z'/%3E%3C/svg%3E\")";
        
        const titleElement = document.createElement('div');
        titleElement.className = 'dialog-title';
        titleElement.textContent = title || 'Warning';
        
        header.appendChild(icon);
        header.appendChild(titleElement);
        dialog.appendChild(header);
        
        const content = document.createElement('div');
        content.className = 'dialog-content';
        content.innerHTML = message || 'Simulated WINCAT error';
        dialog.appendChild(content);
        
        const buttons = document.createElement('div');
        buttons.className = 'dialog-buttons';
        
        const okButton = document.createElement('button');
        okButton.className = 'dialog-button';
        okButton.textContent = 'OK';
        okButton.addEventListener('click', () => {
            dialog.remove();
        });
        
        buttons.appendChild(okButton);
        dialog.appendChild(buttons);
        
        document.body.appendChild(dialog);
        
        return dialog;
    }
    
    function playErrorSound() {
        if (config.settings.soundEffects) {
            const errorSound = new Audio(config.settings.sounds.error);
            errorSound.play().catch(e => console.log("Audio playback failed:", e));
        }
    }
}

function makeWindowDraggable(window, handle) {
    let isDragging = false;
    let offsetX, offsetY;
    
    handle.addEventListener('mousedown', (e) => {
        if (e.target.classList.contains('window-button')) return;
        
        isDragging = true;
        
        const rect = window.getBoundingClientRect();
        offsetX = e.clientX - rect.left;
        offsetY = e.clientY - rect.top;
    });
    
    document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        
        const left = e.clientX - offsetX;
        const top = e.clientY - offsetY;
        
        window.style.left = left + 'px';
        window.style.top = top + 'px';
    });
    
    document.addEventListener('mouseup', () => {
        isDragging = false;
    });
}

function createTaskbarItem(window) {
    const taskItems = document.querySelector('.task-items');
    
    const taskItem = document.createElement('div');
    taskItem.className = 'task-item active';
    
    const iconImg = document.createElement('div');
    iconImg.className = 'icon-img wincatclean-icon';
    
    const label = document.createElement('span');
    label.textContent = 'WINCATclean';
    
    taskItem.appendChild(iconImg);
    taskItem.appendChild(label);
    
    taskItem.addEventListener('click', () => {
        if (window.style.display === 'none') {
            window.style.display = 'flex';
            taskItem.classList.add('active');
        } else {
            window.style.display = 'none';
            taskItem.classList.remove('active');
        }
    });
    
    taskItems.appendChild(taskItem);
    window.taskItem = taskItem;
}

function getAppTitle(appName) {
    switch (appName) {
        case 'notepad': return 'Untitled - Notepad';
        case 'minesweeper': return 'Minesweeper';
        case 'explorer': return 'My Computer';
        case 'about': return 'About Windows 98 Remake';
        case 'google': return 'Google - Internet Explorer';
        default: return 'Window';
    }
}