// SpyKitty Antivirus application module
import * as config from 'config';
import { showDownloadNotification, createDesktopIcon, desktopIconExists } from './desktop-manager.js';

export function createSpyKittyWebsite(content) {
    content.innerHTML = `
        <div class="spykitty-website">
            <h1>SpyKitty Antivirus</h1>
            <p>Protect your computer from dangerous viruses and spyware!</p>
            <p>Our award-winning antivirus protects against all common threats.</p>
            <div class="download-section">
                <div class="download-icon">
                    <svg width="64" height="64" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10" fill="#00aa00" />
                        <path d="M7,12 L11,16 L17,9" stroke="white" stroke-width="2" fill="none" />
                        <path d="M8,7 C10,5 14,5 16,7" stroke="white" stroke-width="1.5" fill="none" />
                        <circle cx="9" cy="9" r="1" fill="white" />
                        <circle cx="15" cy="9" r="1" fill="white" />
                    </svg>
                </div>
                <button class="download-button">DOWNLOAD SPYKITTY.EXE</button>
            </div>
        </div>
    `;
    
    // Add click event for download button
    const downloadButton = content.querySelector('.download-button');
    downloadButton.addEventListener('click', () => {
        if (!desktopIconExists('spykitty')) {
            showDownloadNotification('spykitty', 'Download Complete', startSpyKittySetup, 'spykitty-icon');
        } else {
            alert('SPYKITTY.EXE is already downloaded.');
        }
    });
}

function showSpyKittyDownloadedFile() {
    createDesktopIcon('spykitty', 'SPYKITTY.EXE', 'spykitty-icon');
}

function startSpyKittySetup() {
    const setupWindow = document.createElement('div');
    setupWindow.className = 'window';
    setupWindow.style.width = '450px';
    setupWindow.style.height = '350px';
    setupWindow.style.left = '50%';
    setupWindow.style.top = '50%';
    setupWindow.style.transform = 'translate(-50%, -50%)';
    setupWindow.style.zIndex = '10000';
    
    const windowHeader = document.createElement('div');
    windowHeader.className = 'window-header';
    
    const windowTitle = document.createElement('div');
    windowTitle.className = 'window-title';
    windowTitle.textContent = 'SpyKitty Antivirus Setup Wizard';
    
    windowHeader.appendChild(windowTitle);
    
    const windowControls = document.createElement('div');
    windowControls.className = 'window-controls';
    
    const closeButton = document.createElement('div');
    closeButton.className = 'window-button close';
    closeButton.innerHTML = 'x';
    closeButton.addEventListener('click', () => {
        setupWindow.remove();
    });
    
    windowControls.appendChild(closeButton);
    windowHeader.appendChild(windowControls);
    setupWindow.appendChild(windowHeader);
    
    const windowContent = document.createElement('div');
    windowContent.className = 'window-content setup-content';
    
    windowContent.innerHTML = `
        <div class="setup-wizard">
            <div class="setup-header">
                <svg width="48" height="48" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10" fill="#00aa00" />
                    <path d="M7,12 L11,16 L17,9" stroke="white" stroke-width="2" fill="none" />
                    <path d="M8,7 C10,5 14,5 16,7" stroke="white" stroke-width="1.5" fill="none" />
                    <circle cx="9" cy="9" r="1" fill="white" />
                    <circle cx="15" cy="9" r="1" fill="white" />
                </svg>
                <h2>Welcome to SpyKitty Antivirus</h2>
            </div>
            <div class="setup-body">
                <p>This wizard will guide you through the installation of SpyKitty Antivirus.</p>
                <p>Click Next to continue.</p>
                
                <div class="progress-bar">
                    <div class="progress-fill"></div>
                </div>
                
                <div class="license-agreement">
                    <h3>License Agreement</h3>
                    <div class="license-text">
                        END USER LICENSE AGREEMENT FOR SPYKITTY ANTIVIRUS
                        
                        By installing this software, you agree to:
                        1. Use SpyKitty Antivirus to scan for and remove viruses and spyware
                        2. Allow automatic updates to keep your protection current
                        3. Respect the intellectual property rights of SpyKitty Inc.
                        
                        SpyKitty Inc. guarantees:
                        1. Privacy of your personal information
                        2. Regular updates for virus definitions
                        3. 24/7 protection against malware
                    </div>
                    <label>
                        <input type="checkbox" id="agree-checkbox"> I agree to the terms
                    </label>
                </div>
            </div>
            <div class="setup-footer">
                <button class="setup-button" id="next-button">Next</button>
                <button class="setup-button" id="cancel-button">Cancel</button>
            </div>
        </div>
    `;
    
    setupWindow.appendChild(windowContent);
    document.getElementById('windows-container').appendChild(setupWindow);
    
    // Setup the buttons
    const nextButton = windowContent.querySelector('#next-button');
    const cancelButton = windowContent.querySelector('#cancel-button');
    const agreeCheckbox = windowContent.querySelector('#agree-checkbox');
    
    nextButton.addEventListener('click', () => {
        if (!agreeCheckbox.checked) {
            alert('You must agree to the terms to continue.');
            return;
        }
        
        // Show installation progress
        const licenseAgreement = windowContent.querySelector('.license-agreement');
        licenseAgreement.style.display = 'none';
        
        const setupBody = windowContent.querySelector('.setup-body');
        setupBody.innerHTML = `
            <p>Installing SpyKitty Antivirus...</p>
            <p>Please wait while we install the software on your computer.</p>
            
            <div class="progress-bar">
                <div class="progress-fill" style="width: 0%"></div>
            </div>
            
            <div class="install-status">
                <p id="status-text">Copying files...</p>
            </div>
        `;
        
        nextButton.disabled = true;
        cancelButton.disabled = true;
        
        const progressFill = setupBody.querySelector('.progress-fill');
        const statusText = setupBody.querySelector('#status-text');
        
        let progress = 0;
        const interval = setInterval(() => {
            progress += 5;
            progressFill.style.width = progress + '%';
            
            if (progress === 25) {
                statusText.textContent = 'Initializing virus definitions...';
            } else if (progress === 50) {
                statusText.textContent = 'Setting up realtime protection...';
            } else if (progress === 75) {
                statusText.textContent = 'Finalizing installation...';
            }
            
            if (progress >= 100) {
                clearInterval(interval);
                setupComplete(setupWindow);
            }
        }, 200);
    });
    
    cancelButton.addEventListener('click', () => {
        setupWindow.remove();
    });
}

function setupComplete(setupWindow) {
    const windowContent = setupWindow.querySelector('.window-content');
    
    windowContent.innerHTML = `
        <div class="setup-wizard">
            <div class="setup-header">
                <svg width="48" height="48" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10" fill="#00aa00" />
                    <path d="M7,12 L11,16 L17,9" stroke="white" stroke-width="2" fill="none" />
                    <path d="M8,7 C10,5 14,5 16,7" stroke="white" stroke-width="1.5" fill="none" />
                    <circle cx="9" cy="9" r="1" fill="white" />
                    <circle cx="15" cy="9" r="1" fill="white" />
                </svg>
                <h2>Installation Complete</h2>
            </div>
            <div class="setup-body">
                <p>SpyKitty Antivirus has been successfully installed on your computer.</p>
                <p>Click Finish to close the setup wizard and launch SpyKitty Antivirus.</p>
            </div>
            <div class="setup-footer">
                <button class="setup-button" id="finish-button">Finish</button>
            </div>
        </div>
    `;
    
    const finishButton = windowContent.querySelector('#finish-button');
    finishButton.addEventListener('click', () => {
        setupWindow.remove();
        launchSpyKittyApp();
    });
}

export function launchSpyKittyApp() {
    // Create new window for SpyKitty
    const window = document.createElement('div');
    window.className = 'window';
    window.dataset.app = 'spykitty';
    window.style.width = '600px';
    window.style.height = '400px';
    window.style.left = '50%';
    window.style.top = '50%';
    window.style.transform = 'translate(-50%, -50%)';
    window.style.zIndex = '1000';
    
    // Create window header
    const windowHeader = document.createElement('div');
    windowHeader.className = 'window-header';
    
    const windowTitle = document.createElement('div');
    windowTitle.className = 'window-title';
    
    const iconImg = document.createElement('div');
    iconImg.className = 'icon-img spykitty-icon';
    windowTitle.appendChild(iconImg);
    
    const titleText = document.createElement('span');
    titleText.textContent = 'SpyKitty Antivirus';
    windowTitle.appendChild(titleText);
    
    windowHeader.appendChild(windowTitle);
    
    const windowControls = document.createElement('div');
    windowControls.className = 'window-controls';
    
    const minimizeButton = document.createElement('div');
    minimizeButton.className = 'window-button minimize';
    minimizeButton.innerHTML = '_';
    minimizeButton.addEventListener('click', () => {
        window.style.display = 'none';
    });
    
    const maximizeButton = document.createElement('div');
    maximizeButton.className = 'window-button fullscreen';
    maximizeButton.innerHTML = '□';
    
    const closeButton = document.createElement('div');
    closeButton.className = 'window-button close';
    closeButton.innerHTML = 'x';
    closeButton.addEventListener('click', () => {
        window.remove();
    });
    
    windowControls.appendChild(minimizeButton);
    windowControls.appendChild(maximizeButton);
    windowControls.appendChild(closeButton);
    windowHeader.appendChild(windowControls);
    window.appendChild(windowHeader);
    
    // Create window content
    const windowContent = document.createElement('div');
    windowContent.className = 'window-content spykitty-content';
    
    windowContent.innerHTML = `
        <div class="spykitty-app">
            <div class="spykitty-header">
                <div class="spykitty-logo">
                    <svg width="64" height="64" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10" fill="#00aa00" />
                        <path d="M7,12 L11,16 L17,9" stroke="white" stroke-width="2" fill="none" />
                        <path d="M8,7 C10,5 14,5 16,7" stroke="white" stroke-width="1.5" fill="none" />
                        <circle cx="9" cy="9" r="1" fill="white" />
                        <circle cx="15" cy="9" r="1" fill="white" />
                    </svg>
                </div>
                <div class="spykitty-title">
                    <h2>SpyKitty Antivirus</h2>
                    <p>Keeping your computer safe</p>
                </div>
            </div>
            <div class="spykitty-tabs">
                <button class="spykitty-tab active" data-tab="status">Status</button>
                <button class="spykitty-tab" data-tab="scan">Scan</button>
                <button class="spykitty-tab" data-tab="threats">Threats</button>
                <button class="spykitty-tab" data-tab="settings">Settings</button>
            </div>
            <div class="spykitty-tab-content" id="status-tab">
                <div class="status-card">
                    <h3>System Status: Protected</h3>
                    <div class="status-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="10" fill="#00aa00" />
                            <path d="M7,12 L11,16 L17,9" stroke="white" stroke-width="2" fill="none" />
                        </svg>
                    </div>
                    <p>Your system is protected against viruses and spyware.</p>
                    <div class="status-details">
                        <div class="status-item">
                            <span>Real-time Protection:</span>
                            <span class="status-on">ON</span>
                        </div>
                        <div class="status-item">
                            <span>Last Scan:</span>
                            <span>Never</span>
                        </div>
                        <div class="status-item">
                            <span>Virus Definitions:</span>
                            <span>Up to date</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="spykitty-tab-content hidden" id="scan-tab">
                <div class="scan-options">
                    <h3>Scan Options</h3>
                    <button class="scan-button" id="quick-scan">Quick Scan</button>
                    <button class="scan-button" id="full-scan">Full System Scan</button>
                    <button class="scan-button" id="custom-scan">Custom Scan</button>
                    
                    <div class="scan-progress hidden">
                        <h4>Scanning System...</h4>
                        <div class="progress-bar">
                            <div class="progress-fill"></div>
                        </div>
                        <p class="scan-status">Checking: C:\\Windows\\System32</p>
                        <button class="cancel-scan">Cancel</button>
                    </div>
                </div>
            </div>
            <div class="spykitty-tab-content hidden" id="threats-tab">
                <div class="threats-list">
                    <h3>Detected Threats</h3>
                    <p class="no-threats">No threats have been detected on your system.</p>
                    <div class="threat-items"></div>
                </div>
            </div>
            <div class="spykitty-tab-content hidden" id="settings-tab">
                <div class="settings-options">
                    <h3>Protection Settings</h3>
                    <div class="setting-item">
                        <label>
                            <input type="checkbox" checked> Enable Real-time Protection
                        </label>
                    </div>
                    <div class="setting-item">
                        <label>
                            <input type="checkbox" checked> Start SpyKitty when Windows starts
                        </label>
                    </div>
                    <div class="setting-item">
                        <label>
                            <input type="checkbox" checked> Check for updates automatically
                        </label>
                    </div>
                    <div class="setting-item">
                        <label>
                            <input type="checkbox" checked> Enable Cloud Protection
                        </label>
                    </div>
                    <div class="setting-item">
                        <label>
                            <input type="checkbox"> Show notifications in taskbar
                        </label>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    window.appendChild(windowContent);
    document.getElementById('windows-container').appendChild(window);
    
    // Set up tabs functionality
    const tabs = windowContent.querySelectorAll('.spykitty-tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Hide all tab content
            const tabContents = windowContent.querySelectorAll('.spykitty-tab-content');
            tabContents.forEach(content => content.classList.add('hidden'));
            
            // Remove active class from all tabs
            tabs.forEach(t => t.classList.remove('active'));
            
            // Show the selected tab content
            const tabName = tab.dataset.tab;
            const selectedTab = windowContent.querySelector(`#${tabName}-tab`);
            selectedTab.classList.remove('hidden');
            
            // Add active class to clicked tab
            tab.classList.add('active');
        });
    });
    
    // Set up scan buttons
    const quickScanButton = windowContent.querySelector('#quick-scan');
    const fullScanButton = windowContent.querySelector('#full-scan');
    const customScanButton = windowContent.querySelector('#custom-scan');
    const scanOptions = windowContent.querySelector('.scan-options');
    const scanProgress = windowContent.querySelector('.scan-progress');
    const cancelScanButton = windowContent.querySelector('.cancel-scan');
    const progressFill = windowContent.querySelector('.progress-fill');
    const scanStatus = windowContent.querySelector('.scan-status');
    
    function startScan(scanType) {
        scanOptions.querySelectorAll('.scan-button').forEach(btn => {
            btn.classList.add('hidden');
        });
        scanProgress.classList.remove('hidden');
        
        let progress = 0;
        const scanFiles = [
            'C:\\Windows\\System32',
            'C:\\Program Files',
            'C:\\Users',
            'C:\\Documents and Settings',
            'C:\\ILOVEYOU.EXE',
            'C:\\BUTTERFLY.EXE'
        ];
        
        let fileIndex = 0;
        const scanInterval = setInterval(() => {
            progress += 1;
            progressFill.style.width = progress + '%';
            
            if (progress % 16 === 0 && fileIndex < scanFiles.length) {
                scanStatus.textContent = 'Checking: ' + scanFiles[fileIndex];
                fileIndex++;
            }
            
            if (progress >= 100) {
                clearInterval(scanInterval);
                completeScan();
            }
        }, 100);
        
        // Store the interval to be able to cancel it
        window.scanInterval = scanInterval;
    }
    
    function completeScan() {
        scanProgress.classList.add('hidden');
        scanOptions.querySelectorAll('.scan-button').forEach(btn => {
            btn.classList.remove('hidden');
        });
        
        const threatsTab = document.querySelector('button[data-tab="threats"]');
        threatsTab.click();
        
        // Add detected threats if virus or butterfly exists
        const threatsList = document.querySelector('.threat-items');
        const noThreats = document.querySelector('.no-threats');
        
        if (document.querySelector('.icon[data-app="iloveyou"]') || 
            document.querySelector('.icon[data-app="butterfly"]') ||
            document.querySelectorAll('.butterfly-virus').length > 0) {
            
            noThreats.style.display = 'none';
            threatsList.innerHTML = '';
            
            if (document.querySelector('.icon[data-app="iloveyou"]')) {
                threatsList.innerHTML += `
                    <div class="threat-item">
                        <div class="threat-icon">⚠️</div>
                        <div class="threat-info">
                            <h4>ILOVEYOU.EXE</h4>
                            <p>Type: Worm</p>
                            <p>Location: C:\\ILOVEYOU.EXE</p>
                            <p>Risk: High</p>
                        </div>
                        <button class="threat-action">Remove</button>
                    </div>
                `;
            }
            
            if (document.querySelector('.icon[data-app="butterfly"]') || 
                document.querySelectorAll('.butterfly-virus').length > 0) {
                threatsList.innerHTML += `
                    <div class="threat-item">
                        <div class="threat-icon">⚠️</div>
                        <div class="threat-info">
                            <h4>BUTTERFLY.EXE</h4>
                            <p>Type: Spyware</p>
                            <p>Location: C:\\BUTTERFLY.EXE</p>
                            <p>Risk: Medium</p>
                        </div>
                        <button class="threat-action">Remove</button>
                    </div>
                `;
            }
            
            // Add remove functionality
            const removeButtons = threatsList.querySelectorAll('.threat-action');
            removeButtons.forEach(button => {
                button.addEventListener('click', (e) => {
                    const threatItem = e.target.closest('.threat-item');
                    const threatName = threatItem.querySelector('h4').textContent;
                    
                    if (threatName === 'ILOVEYOU.EXE') {
                        // Remove ILOVEYOU icon and virus windows
                        const icon = document.querySelector('.icon[data-app="iloveyou"]');
                        if (icon) icon.remove();
                        
                        document.querySelectorAll('.virus-window').forEach(vw => vw.remove());
                    }
                    
                    if (threatName === 'BUTTERFLY.EXE') {
                        // Remove butterfly icon and butterflies
                        const icon = document.querySelector('.icon[data-app="butterfly"]');
                        if (icon) icon.remove();
                        
                        document.querySelectorAll('.butterfly-virus').forEach(bv => bv.remove());
                    }
                    
                    threatItem.innerHTML = `
                        <div class="threat-removed">
                            <span>✓</span> ${threatName} has been successfully removed.
                        </div>
                    `;
                    
                    // If all threats are removed, show no threats message
                    const remainingThreats = threatsList.querySelectorAll('.threat-action').length;
                    if (remainingThreats === 0) {
                        setTimeout(() => {
                            noThreats.style.display = 'block';
                            threatsList.innerHTML = '';
                        }, 3000);
                    }
                });
            });
            
        } else {
            noThreats.style.display = 'block';
            threatsList.innerHTML = '';
        }
    }
    
    quickScanButton.addEventListener('click', () => startScan('quick'));
    fullScanButton.addEventListener('click', () => startScan('full'));
    customScanButton.addEventListener('click', () => startScan('custom'));
    
    cancelScanButton.addEventListener('click', () => {
        if (window.scanInterval) {
            clearInterval(window.scanInterval);
        }
        scanProgress.classList.add('hidden');
        scanOptions.querySelectorAll('.scan-button').forEach(btn => {
            btn.classList.remove('hidden');
        });
    });

    // Register window in task manager and make draggable
    makeWindowDraggable(window, windowHeader);
}

function makeWindowDraggable(window, handle) {
    let isDragging = false;
    let offsetX, offsetY;
    
    handle.addEventListener('mousedown', (e) => {
        if (e.target.classList.contains('window-button')) return;
        
        isDragging = true;
        
        const rect = window.getBoundingClientRect();
        offsetX = e.clientX - rect.left;
        offsetY = e.clientY - rect.top;
    });
    
    document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        
        const left = e.clientX - offsetX;
        const top = e.clientY - offsetY;
        
        window.style.left = left + 'px';
        window.style.top = top + 'px';
    });
    
    document.addEventListener('mouseup', () => {
        isDragging = false;
    });
}