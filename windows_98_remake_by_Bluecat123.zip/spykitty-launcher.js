// SpyKitty App Launcher - Split from spykitty-app.js
import * as config from 'config';
import { performDeepScan, showNotification, setupRealTimeProtection, 
         createScheduledScanScreen, createQuarantineScreen, createUpdateScreen } from './spykitty-enhanced.js';
import { createSpyKittyWebsite } from './spykitty-app.js';

export function launchEnhancedSpyKittyApp() {
    // Create new window for SpyKitty
    const window = document.createElement('div');
    window.className = 'window';
    window.dataset.app = 'spykitty';
    window.style.width = '750px';  // Wider window
    window.style.height = '500px'; // Taller window
    window.style.left = '50%';
    window.style.top = '50%';
    window.style.transform = 'translate(-50%, -50%)';
    window.style.zIndex = '1000';
    
    // Create window header
    const windowHeader = document.createElement('div');
    windowHeader.className = 'window-header';
    
    const windowTitle = document.createElement('div');
    windowTitle.className = 'window-title';
    
    const iconImg = document.createElement('div');
    iconImg.className = 'icon-img spykitty-icon';
    windowTitle.appendChild(iconImg);
    
    const titleText = document.createElement('span');
    titleText.textContent = 'SpyKitty Antivirus - Enhanced Edition';
    windowTitle.appendChild(titleText);
    
    windowHeader.appendChild(windowTitle);
    
    const windowControls = document.createElement('div');
    windowControls.className = 'window-controls';
    
    const minimizeButton = document.createElement('div');
    minimizeButton.className = 'window-button minimize';
    minimizeButton.innerHTML = '_';
    minimizeButton.addEventListener('click', () => {
        window.style.display = 'none';
    });
    
    const maximizeButton = document.createElement('div');
    maximizeButton.className = 'window-button fullscreen';
    maximizeButton.innerHTML = '□';
    
    const closeButton = document.createElement('div');
    closeButton.className = 'window-button close';
    closeButton.innerHTML = 'x';
    closeButton.addEventListener('click', () => {
        window.remove();
    });
    
    windowControls.appendChild(minimizeButton);
    windowControls.appendChild(maximizeButton);
    windowControls.appendChild(closeButton);
    windowHeader.appendChild(windowControls);
    window.appendChild(windowHeader);
    
    // Create window content
    const windowContent = document.createElement('div');
    windowContent.className = 'window-content spykitty-content';
    
    windowContent.innerHTML = `
        <div class="spykitty-app">
            <div class="spykitty-header">
                <div class="spykitty-logo">
                    <svg width="64" height="64" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10" fill="#00aa00" />
                        <path d="M7,12 L11,16 L17,9" stroke="white" stroke-width="2" fill="none" />
                        <path d="M8,7 C10,5 14,5 16,7" stroke="white" stroke-width="1.5" fill="none" />
                        <circle cx="9" cy="9" r="1" fill="white" />
                        <circle cx="15" cy="9" r="1" fill="white" />
                    </svg>
                </div>
                <div class="spykitty-title">
                    <h2>SpyKitty Antivirus</h2>
                    <p>Enhanced Protection - v2.5</p>
                </div>
                <div class="protection-indicator">
                    <div class="indicator-dot"></div>
                    <span>Protection Active</span>
                </div>
            </div>
            <div class="spykitty-tabs">
                <button class="spykitty-tab active" data-tab="status">Dashboard</button>
                <button class="spykitty-tab" data-tab="scan">Scan</button>
                <button class="spykitty-tab" data-tab="threats">Threats</button>
                <button class="spykitty-tab" data-tab="quarantine">Quarantine</button>
                <button class="spykitty-tab" data-tab="scheduled">Scheduled</button>
                <button class="spykitty-tab" data-tab="update">Updates</button>
                <button class="spykitty-tab" data-tab="settings">Settings</button>
            </div>
            <div class="spykitty-tab-content" id="status-tab">
                <div class="status-card">
                    <h3>System Status: Protected</h3>
                    <div class="status-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="10" fill="#00aa00" />
                            <path d="M7,12 L11,16 L17,9" stroke="white" stroke-width="2" fill="none" />
                        </svg>
                    </div>
                    
                    <div class="dashboard-stats">
                        <div class="stat-card">
                            <div class="stat-value">0</div>
                            <div class="stat-label">Active Threats</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value">0</div>
                            <div class="stat-label">Quarantined Items</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value">1</div>
                            <div class="stat-label">Scans Today</div>
                        </div>
                    </div>
                    
                    <p>Your system is protected against viruses, spyware, and other malware.</p>
                    <div class="status-details">
                        <div class="status-item">
                            <span>Real-time Protection:</span>
                            <span class="status-on">ON</span>
                        </div>
                        <div class="status-item">
                            <span>Last Scan:</span>
                            <span>${new Date().toLocaleString()}</span>
                        </div>
                        <div class="status-item">
                            <span>Virus Definitions:</span>
                            <span>Up to date (2023.11.${Math.floor(Math.random() * 30) + 1})</span>
                        </div>
                        <div class="status-item">
                            <span>License Status:</span>
                            <span>Premium (Valid until ${new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toLocaleDateString()})</span>
                        </div>
                    </div>
                    
                    <div class="quick-actions">
                        <button class="primary-button" id="quick-scan-button">Quick Scan</button>
                        <button id="view-threats-button">View Threats</button>
                    </div>
                </div>
            </div>
            <div class="spykitty-tab-content hidden" id="scan-tab">
                <div class="scan-options">
                    <h3>Scan Options</h3>
                    <button class="scan-button" id="quick-scan">Quick Scan</button>
                    <button class="scan-button" id="full-scan">Full System Scan</button>
                    <button class="scan-button" id="custom-scan">Custom Scan</button>
                    
                    <div class="scan-progress hidden">
                        <h4>Scanning System...</h4>
                        <div class="progress-bar">
                            <div class="progress-fill"></div>
                        </div>
                        <p class="scan-status">Initializing scan...</p>
                        <button class="cancel-scan">Cancel</button>
                    </div>
                </div>
            </div>
            <div class="spykitty-tab-content hidden" id="threats-tab">
                <div class="threats-list">
                    <h3>Detected Threats</h3>
                    <p class="no-threats">No threats have been detected on your system.</p>
                    <div class="threat-items"></div>
                </div>
            </div>
            <div class="spykitty-tab-content hidden" id="settings-tab">
                <div class="settings-options">
                    <h3>Protection Settings</h3>
                    <div class="setting-item">
                        <label>
                            <input type="checkbox" checked id="realtime-protection"> Enable Real-time Protection
                        </label>
                    </div>
                    <div class="setting-item">
                        <label>
                            <input type="checkbox" checked> Start SpyKitty when Windows starts
                        </label>
                    </div>
                    <div class="setting-item">
                        <label>
                            <input type="checkbox" checked> Check for updates automatically
                        </label>
                    </div>
                    <div class="setting-item">
                        <label>
                            <input type="checkbox" checked> Enable Cloud Protection
                        </label>
                    </div>
                    <div class="setting-item">
                        <label>
                            <input type="checkbox" checked> Show notifications in taskbar
                        </label>
                    </div>
                    <div class="setting-item">
                        <label>
                            <input type="checkbox" checked> Play sound alerts
                        </label>
                    </div>
                    
                    <div class="setting-section">
                        <h4>Scan Settings</h4>
                        <div class="setting-item">
                            <label>
                                <input type="checkbox" checked> Scan compressed files
                            </label>
                        </div>
                        <div class="setting-item">
                            <label>
                                <input type="checkbox" checked> Scan email attachments
                            </label>
                        </div>
                        <div class="setting-item">
                            <label>
                                <input type="checkbox" checked> Enable heuristic analysis
                            </label>
                        </div>
                    </div>
                    
                    <button class="primary-button save-settings">Save Settings</button>
                </div>
            </div>
        </div>
    `;
    
    window.appendChild(windowContent);
    document.getElementById('windows-container').appendChild(window);
    
    // Add the new tab contents
    const tabsContainer = windowContent.querySelector('.spykitty-tabs');
    const contentContainer = windowContent.querySelector('.spykitty-app');
    
    // Add quarantine tab content
    contentContainer.appendChild(createQuarantineScreen(windowContent));
    
    // Add scheduled tab content
    contentContainer.appendChild(createScheduledScanScreen(windowContent));
    
    // Add update tab content
    contentContainer.appendChild(createUpdateScreen(windowContent));
    
    // Set up tabs functionality
    const tabs = windowContent.querySelectorAll('.spykitty-tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Hide all tab content
            const tabContents = windowContent.querySelectorAll('.spykitty-tab-content');
            tabContents.forEach(content => content.classList.add('hidden'));
            
            // Remove active class from all tabs
            tabs.forEach(t => t.classList.remove('active'));
            
            // Show the selected tab content
            const tabName = tab.dataset.tab;
            const selectedTab = windowContent.querySelector(`#${tabName}-tab`);
            selectedTab.classList.remove('hidden');
            
            // Add active class to clicked tab
            tab.classList.add('active');
        });
    });
    
    // Set up scan buttons
    setupScanFunctionality(windowContent);
    
    // Setup real-time protection
    const realTimeProtection = setupRealTimeProtection(windowContent);
    
    // Add real-time protection toggle functionality
    const protectionToggle = windowContent.querySelector('#realtime-protection');
    const protectionIndicator = windowContent.querySelector('.protection-indicator');
    
    protectionToggle.addEventListener('change', () => {
        if (protectionToggle.checked) {
            protectionIndicator.classList.remove('inactive');
            protectionIndicator.querySelector('span').textContent = 'Protection Active';
            realTimeProtection.isActive = true;
        } else {
            protectionIndicator.classList.add('inactive');
            protectionIndicator.querySelector('span').textContent = 'Protection Disabled';
            realTimeProtection.isActive = false;
            
            // Show warning notification
            showNotification('Warning', 'Real-time protection is disabled. Your system is at risk!');
        }
    });
    
    // Setup dashboard buttons
    const quickScanButton = windowContent.querySelector('#quick-scan-button');
    const viewThreatsButton = windowContent.querySelector('#view-threats-button');
    
    quickScanButton.addEventListener('click', () => {
        const scanTab = windowContent.querySelector('button[data-tab="scan"]');
        scanTab.click();
        const quickScanBtn = windowContent.querySelector('#quick-scan');
        quickScanBtn.click();
    });
    
    viewThreatsButton.addEventListener('click', () => {
        const threatsTab = windowContent.querySelector('button[data-tab="threats"]');
        threatsTab.click();
    });
    
    // Setup scheduled scan save button
    const saveScheduleButton = windowContent.querySelector('#save-schedule');
    if (saveScheduleButton) {
        saveScheduleButton.addEventListener('click', () => {
            const enableSchedule = windowContent.querySelector('#enable-schedule');
            const frequency = windowContent.querySelector('#scan-frequency');
            const time = windowContent.querySelector('#scan-time');
            const scanType = windowContent.querySelector('#scheduled-scan-type');
            
            if (enableSchedule && enableSchedule.checked) {
                showNotification('Schedule Updated', `Scan scheduled for ${frequency.value} at ${time.value}`);
            } else {
                showNotification('Schedule Disabled', 'Scheduled scans have been disabled');
            }
        });
    }
    
    // Setup update check button
    const checkUpdatesButton = windowContent.querySelector('#check-updates');
    if (checkUpdatesButton) {
        checkUpdatesButton.addEventListener('click', () => {
            checkUpdatesButton.disabled = true;
            checkUpdatesButton.textContent = 'Checking...';
            
            setTimeout(() => {
                checkUpdatesButton.disabled = false;
                checkUpdatesButton.textContent = 'Check for Updates';
                showNotification('Update Check', 'Your virus definitions are already up to date');
            }, 2000);
        });
    }
    
    // Save settings button
    const saveSettingsButton = windowContent.querySelector('.save-settings');
    if (saveSettingsButton) {
        saveSettingsButton.addEventListener('click', () => {
            showNotification('Settings Saved', 'Your settings have been updated successfully');
        });
    }
    
    // Show welcome notification
    setTimeout(() => {
        showNotification('SpyKitty Active', 'Your system is being protected against viruses and malware.');
    }, 1000);

    // Register window in task manager and make draggable
    makeWindowDraggable(window, windowHeader);
}

function setupScanFunctionality(windowContent) {
    const quickScanButton = windowContent.querySelector('#quick-scan');
    const fullScanButton = windowContent.querySelector('#full-scan');
    const customScanButton = windowContent.querySelector('#custom-scan');
    const scanOptions = windowContent.querySelector('.scan-options');
    const scanProgress = windowContent.querySelector('.scan-progress');
    const cancelScanButton = windowContent.querySelector('.cancel-scan');
    
    function startScan(scanType) {
        scanOptions.querySelectorAll('.scan-button').forEach(btn => {
            btn.classList.add('hidden');
        });
        scanProgress.classList.remove('hidden');
        
        // Use enhanced deep scan functionality
        const scanInterval = performDeepScan(windowContent, scanType);
        
        // Store the interval to be able to cancel it
        window.scanInterval = scanInterval;
    }
    
    quickScanButton.addEventListener('click', () => startScan('quick'));
    fullScanButton.addEventListener('click', () => startScan('full'));
    customScanButton.addEventListener('click', () => startScan('custom'));
    
    cancelScanButton.addEventListener('click', () => {
        if (window.scanInterval) {
            clearInterval(window.scanInterval);
        }
        scanProgress.classList.add('hidden');
        scanOptions.querySelectorAll('.scan-button').forEach(btn => {
            btn.classList.remove('hidden');
        });
    });
}

function makeWindowDraggable(window, handle) {
    let isDragging = false;
    let offsetX, offsetY;
    
    handle.addEventListener('mousedown', (e) => {
        if (e.target.classList.contains('window-button')) return;
        
        isDragging = true;
        
        const rect = window.getBoundingClientRect();
        offsetX = e.clientX - rect.left;
        offsetY = e.clientY - rect.top;
    });
    
    document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        
        const left = e.clientX - offsetX;
        const top = e.clientY - offsetY;
        
        window.style.left = left + 'px';
        window.style.top = top + 'px';
    });
    
    document.addEventListener('mouseup', () => {
        isDragging = false;
    });
}