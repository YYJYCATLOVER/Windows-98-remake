// Lockcat virus module that simulates a ransomware attack
import * as config from 'config';
import { showDownloadNotification, createDesktopIcon, desktopIconExists } from './desktop-manager.js';

export function createFreeGameWebsite(content) {
    content.innerHTML = `
        <div class="freegame-website">
            <h1>Free Games Download Center</h1>
            <p>Get the latest games completely FREE! No virus, guaranteed!</p>
            <div class="games-section">
                <div class="game-item">
                    <div class="game-icon">
                        <svg width="64" height="64" viewBox="0 0 24 24">
                            <rect x="2" y="3" width="20" height="18" rx="2" fill="#444" />
                            <rect x="4" y="5" width="16" height="12" rx="1" fill="#88f" />
                            <circle cx="12" cy="20" r="1" fill="#aaa" />
                            <path d="M10,9 L16,12 L10,15 Z" fill="white" />
                        </svg>
                    </div>
                    <h3>Action Game 2023</h3>
                    <p>★★★★★ (1,245 downloads)</p>
                    <button class="download-button">DOWNLOAD NOW</button>
                </div>
                <div class="game-item">
                    <div class="game-icon">
                        <svg width="64" height="64" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="10" fill="#333" />
                            <path d="M8,12 C8,9 12,7 16,9" stroke="#f55" stroke-width="1.5" fill="none" />
                            <path d="M8,12 C8,15 12,17 16,15" stroke="#f55" stroke-width="1.5" fill="none" />
                            <circle cx="9" cy="9" r="1" fill="#f55" />
                            <circle cx="9" cy="15" r="1" fill="#f55" />
                        </svg>
                    </div>
                    <h3>LockCat Game</h3>
                    <p>★★★★★ (3,782 downloads)</p>
                    <button class="download-button" id="lockcat-download">DOWNLOAD NOW</button>
                </div>
                <div class="game-item">
                    <div class="game-icon">
                        <svg width="64" height="64" viewBox="0 0 24 24">
                            <rect x="3" y="3" width="18" height="18" fill="#3a3" />
                            <rect x="5" y="5" width="14" height="14" fill="#5c5" />
                            <rect x="8" y="8" width="8" height="8" fill="#7e7" />
                        </svg>
                    </div>
                    <h3>Strategy World</h3>
                    <p>★★★★☆ (987 downloads)</p>
                    <button class="download-button">DOWNLOAD NOW</button>
                </div>
            </div>
        </div>
    `;
    
    // Add click event for LockCat download button
    const lockcatButton = content.querySelector('#lockcat-download');
    lockcatButton.addEventListener('click', () => {
        if (!desktopIconExists('lockcat')) {
            showDownloadNotification('lockcat', 'Download Complete', executeLockcat, 'lockcat-icon');
        } else {
            alert('LOCKCAT.EXE is already downloaded.');
        }
    });
}

function executeLockcat() {
    // Create a basic confirmation dialog
    const dialog = document.createElement('div');
    dialog.className = 'dialog';
    
    const header = document.createElement('div');
    header.className = 'dialog-header';
    
    const icon = document.createElement('div');
    icon.className = 'dialog-icon';
    icon.style.backgroundImage = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle fill='%23333333' cx='16' cy='16' r='14'/%3E%3Cpath fill='%23ffffff' d='M16 6v10M12 10l4-4 4 4'/%3E%3C/svg%3E\")";
    
    const title = document.createElement('div');
    title.className = 'dialog-title';
    title.textContent = 'Run LockCat.exe?';
    
    header.appendChild(icon);
    header.appendChild(title);
    dialog.appendChild(header);
    
    const content = document.createElement('div');
    content.className = 'dialog-content';
    content.innerHTML = 'Do you want to run LockCat Game?';
    dialog.appendChild(content);
    
    const buttons = document.createElement('div');
    buttons.className = 'dialog-buttons';
    
    const okButton = document.createElement('button');
    okButton.className = 'dialog-button';
    okButton.textContent = 'Run';
    okButton.addEventListener('click', () => {
        dialog.remove();
        startLockCatRansomware();
    });
    
    const cancelButton = document.createElement('button');
    cancelButton.className = 'dialog-button';
    cancelButton.textContent = 'Cancel';
    cancelButton.addEventListener('click', () => {
        dialog.remove();
    });
    
    buttons.appendChild(okButton);
    buttons.appendChild(cancelButton);
    dialog.appendChild(buttons);
    
    document.body.appendChild(dialog);
    
    // Play error sound
    if (config.settings.soundEffects) {
        const errorSound = new Audio(config.settings.sounds.error);
        errorSound.play().catch(e => console.log("Audio playback failed:", e));
    }
}

function startLockCatRansomware() {
    // First close all windows
    document.querySelectorAll('.window').forEach(window => {
        window.remove();
    });
    
    // Close the taskbar items
    document.querySelector('.task-items').innerHTML = '';
    
    // Change background to black
    document.body.style.backgroundColor = '#000';
    document.querySelector('.desktop').style.backgroundColor = '#000';
    document.querySelector('.desktop').style.backgroundImage = 'none';
    
    // Hide all desktop icons
    document.querySelectorAll('.icon').forEach(icon => {
        icon.style.display = 'none';
    });
    
    // Create ransomware screen
    const ransomScreen = document.createElement('div');
    ransomScreen.className = 'lockcat-screen';
    
    // Create content for ransomware screen
    ransomScreen.innerHTML = `
        <div class="lockcat-header">
            <div class="lockcat-logo">
                <svg width="64" height="64" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10" fill="#333" />
                    <path d="M8,12 C8,9 12,7 16,9" stroke="#f55" stroke-width="1.5" fill="none" />
                    <path d="M8,12 C8,15 12,17 16,15" stroke="#f55" stroke-width="1.5" fill="none" />
                    <circle cx="9" cy="9" r="1" fill="#f55" />
                    <circle cx="9" cy="15" r="1" fill="#f55" />
                </svg>
            </div>
            <h1>LOCKCAT RANSOMWARE</h1>
        </div>
        
        <div class="lockcat-message">
            <h2>YOUR FILES HAVE BEEN ENCRYPTED!</h2>
            <p>All your personal files have been encrypted with military-grade encryption.</p>
            <p>To recover your files, you need to enter the decryption code before the timer expires.</p>
            <p>If you fail to enter the code in time, your files will be permanently deleted.</p>
            
            <div class="lockcat-timer">
                <div class="timer-label">TIME REMAINING:</div>
                <div class="timer-value">01:19</div>
            </div>
            
            <div class="lockcat-code-entry">
                <input type="text" id="lockcat-code-input" placeholder="Enter decryption code here">
                <button id="lockcat-submit-code">Decrypt Files</button>
            </div>
            
            <div class="lockcat-file-list">
                <h3>Encrypted Files:</h3>
                <ul>
                    <li>C:\\Users\\Documents\\important_file.docx</li>
                    <li>C:\\Users\\Documents\\tax_return_2023.pdf</li>
                    <li>C:\\Users\\Pictures\\family_photo.jpg</li>
                    <li>C:\\Users\\Downloads\\backup.zip</li>
                    <li>... and 1,248 more files</li>
                </ul>
            </div>
        </div>
    `;
    
    document.body.appendChild(ransomScreen);
    
    // Set up timer
    let timeRemaining = 79; // 1 minute and 19 seconds
    const timerElement = ransomScreen.querySelector('.timer-value');
    
    const timer = setInterval(() => {
        timeRemaining--;
        
        const minutes = Math.floor(timeRemaining / 60);
        const seconds = timeRemaining % 60;
        
        timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        // Play error sound every 10 seconds
        if (timeRemaining % 10 === 0 && config.settings.soundEffects) {
            const errorSound = new Audio(config.settings.sounds.error);
            errorSound.play().catch(e => console.log("Audio playback failed:", e));
        }
        
        // Check if time is up
        if (timeRemaining <= 0) {
            clearInterval(timer);
            showFilesDeletedScreen();
        }
    }, 1000);
    
    // Set up code entry functionality
    const codeInput = ransomScreen.querySelector('#lockcat-code-input');
    const submitButton = ransomScreen.querySelector('#lockcat-submit-code');
    
    submitButton.addEventListener('click', () => {
        checkDecryptionCode(codeInput.value, timer);
    });
    
    codeInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            checkDecryptionCode(codeInput.value, timer);
        }
    });
    
    // Play error sound
    if (config.settings.soundEffects) {
        const errorSound = new Audio(config.settings.sounds.error);
        errorSound.play().catch(e => console.log("Audio playback failed:", e));
    }
}

function checkDecryptionCode(code, timer) {
    // The correct code
    const correctCode = 'CODE99828L0CKERFIX';
    
    if (code.trim() === correctCode) {
        // Clear the timer
        clearInterval(timer);
        
        // Show success screen
        showDecryptionSuccessScreen();
    } else {
        // Show error message
        const errorMessage = document.querySelector('.lockcat-code-entry');
        errorMessage.innerHTML += '<p class="lockcat-error">Incorrect code! Try again.</p>';
        
        // Play error sound
        if (config.settings.soundEffects) {
            const errorSound = new Audio(config.settings.sounds.error);
            errorSound.play().catch(e => console.log("Audio playback failed:", e));
        }
    }
}

function showDecryptionSuccessScreen() {
    // Create success screen
    const successScreen = document.createElement('div');
    successScreen.className = 'lockcat-success-screen';
    
    // Create content for success screen
    successScreen.innerHTML = `
        <div class="lockcat-success-message">
            <svg width="64" height="64" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#4CAF50" />
                <path d="M7,13 L10,16 L17,9" stroke="white" stroke-width="2" fill="none" />
            </svg>
            <h2>DECRYPTION SUCCESSFUL!</h2>
            <p>Your files have been successfully decrypted.</p>
            <p>Thank you for using the correct code.</p>
            <button id="lockcat-restart">Restart System</button>
        </div>
    `;
    
    // Remove existing ransomware screen
    const ransomScreen = document.querySelector('.lockcat-screen');
    if (ransomScreen) {
        ransomScreen.remove();
    }
    
    document.body.appendChild(successScreen);
    
    // Set up restart button
    const restartButton = successScreen.querySelector('#lockcat-restart');
    restartButton.addEventListener('click', () => {
        location.reload();
    });
    
    // Play success sound
    if (config.settings.soundEffects) {
        const dingSound = new Audio(config.settings.sounds.ding);
        dingSound.play().catch(e => console.log("Audio playback failed:", e));
    }
}

function showFilesDeletedScreen() {
    // Create deletion screen
    const deletedScreen = document.createElement('div');
    deletedScreen.className = 'lockcat-deleted-screen';
    
    // Create content for deletion screen
    deletedScreen.innerHTML = `
        <div class="lockcat-deleted-message">
            <svg width="64" height="64" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" fill="#f44336" />
                <path d="M8,8 L16,16 M8,16 L16,8" stroke="white" stroke-width="2" />
            </svg>
            <h2>YOUR FILES ARE GONE FOREVER</h2>
            <p>The decryption time has expired.</p>
            <p>All your files have been permanently deleted.</p>
            <p>There is no way to recover them.</p>
            <button id="lockcat-restart">Restart System</button>
        </div>
    `;
    
    // Remove existing ransomware screen
    const ransomScreen = document.querySelector('.lockcat-screen');
    if (ransomScreen) {
        ransomScreen.remove();
    }
    
    document.body.appendChild(deletedScreen);
    
    // Set up restart button
    const restartButton = deletedScreen.querySelector('#lockcat-restart');
    restartButton.addEventListener('click', () => {
        location.reload();
    });
    
    // Play multiple error sounds
    if (config.settings.soundEffects) {
        for (let i = 0; i < 3; i++) {
            setTimeout(() => {
                const errorSound = new Audio(config.settings.sounds.error);
                errorSound.play().catch(e => console.log("Audio playback failed:", e));
            }, i * 500);
        }
    }
}