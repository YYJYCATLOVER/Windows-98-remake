// Configuration for the Windows 98 Remake system
export const settings = {
    // Desktop background color (in Windows 98 teal)
    backgroundColor: '#008080',
    
    // Default window positions
    defaultWindowWidth: 350,
    defaultWindowHeight: 250,
    
    // Start menu items (you can customize these)
    startMenuItems: [
        'Notepad',
        'Minesweeper',
        'Explorer',
        'Google',
        'About'
    ],
    
    // Sound assets
    sounds: {
        startup: 'microsoft-windows-98-startup-soundmp3_160k.mp3',
        error: 'windows_98_error.mp3',
        ding: 'ding (2).mp3'
    },
    
    // Enable sound effects
    soundEffects: true,
    
    // Clock format (12 or 24 hour)
    clockFormat: 12,
    
    // Virus details
    virus: {
        name: "ILOVEYOU",
        replicationLimit: 10,
        replicationDelay: 1000 // in milliseconds
    },
    
    // Butterfly virus details
    butterfly: {
        initialCount: 5,
        maxButterflies: 20,
        spawnInterval: 10000, // 10 seconds
        dataCollectionRate: 0.2 // 20% chance of collecting data on interaction
    },
    
    // WINCAT virus settings
    wincat: {
        warningDelay: 4000,       // How long to show warning message
        websitePeriod: 4000,      // How often to open websites
        websiteCount: 3,          // How many websites to open
        appPeriod: 2000,          // How often to open apps
        appCount: 5,              // How many apps to open
        colorChangePeriod: 1000,  // How often to change colors
        biosDeathTime: 49000      // When to show BIOS death
    }
};