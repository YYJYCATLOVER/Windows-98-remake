// New file to centralize audio playback functions
import * as config from 'config';

// Play a sound from the config file
export function playSound(soundName) {
    if (config.settings.soundEffects && config.settings.sounds[soundName]) {
        const sound = new Audio(config.settings.sounds[soundName]);
        sound.play().catch(e => console.log("Audio playback failed:", e));
    }
}

// Play with custom volume
export function playSoundWithVolume(soundName, volume) {
    if (config.settings.soundEffects && config.settings.sounds[soundName]) {
        const sound = new Audio(config.settings.sounds[soundName]);
        sound.volume = volume;
        sound.play().catch(e => console.log("Audio playback failed:", e));
    }
}