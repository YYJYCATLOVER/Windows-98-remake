import * as config from 'config';
import { createAboutContent } from './ui-helpers.js';
import * as appWindows from './app-windows.js';
import { launchSpyKittyApp } from './spykitty-app.js';

// Global variables
let windowZIndex = 100;
let activeWindow = null;
let windows = [];
let taskItems = [];
let isDragging = false;
let dragOffsetX = 0;
let dragOffsetY = 0;
let currentDragWindow = null;

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', initStartupSequence);

function initStartupSequence() {
    // Create startup container
    const startupContainer = document.createElement('div');
    startupContainer.className = 'startup-screen';
    document.body.appendChild(startupContainer);
    
    // Step 1: Show Microsoft logo
    const logoImg = document.createElement('img');
    logoImg.className = 'startup-logo';
    logoImg.src = 'Microsoft Logo 2999999985.png';
    startupContainer.appendChild(logoImg);
    
    // After few seconds, show BIOS
    setTimeout(() => {
        startupContainer.innerHTML = '';
        const biosScreen = document.createElement('div');
        biosScreen.className = 'bios-screen';
        biosScreen.innerHTML = `
            Award Modular BIOS v4.51PG<br>
            Copyright (C) 1984-1998, Award Software, Inc.<br><br>
            
            Main Processor: Intel Pentium 166MHz<br>
            Memory Testing: 32768K OK<br><br>
            
            Primary Master: Seagate 3.2GB<br>
            Primary Slave: ATAPI CD-ROM 24X<br>
            Secondary Master: None<br>
            Secondary Slave: None<br><br>
            
            Initializing Plug & Play...<br>
            Detecting Drives...<br>
            Initializing Hard Drive...<br>
            Boot from Hard Disk...<br>
        `;
        startupContainer.appendChild(biosScreen);
        
        // After 0.5 seconds, show Windows 98 splash
        setTimeout(() => {
            startupContainer.innerHTML = '';
            const splashImg = document.createElement('img');
            splashImg.className = 'startup-splash';
            splashImg.src = 'aeki8d7vcxm61.jpg';
            startupContainer.appendChild(splashImg);
            
            // Play startup sound
            if (config.settings.soundEffects) {
                const startupSound = new Audio(config.settings.sounds.startup);
                startupSound.play().catch(e => console.log("Audio playback failed:", e));
            }
            
            // After 5 seconds, remove startup and initialize the desktop
            setTimeout(() => {
                startupContainer.remove();
                init();
            }, 5000);
        }, 500);
    }, 3000);
}

function init() {
    updateClock();
    setInterval(updateClock, 60000);
    
    setupStartMenu();
    setupDesktopIcons();
    addShutdownHandler();
    
    // Close windows if clicking on desktop
    document.querySelector('.desktop').addEventListener('mousedown', (e) => {
        if (e.target.classList.contains('desktop')) {
            document.getElementById('start-menu').classList.add('hidden');
        }
    });
    
    // Make openApp available to the window object for use by desktop icons
    window.openApp = openApp;
}

function updateClock() {
    const now = new Date();
    const hours = now.getHours() % 12 || 12;
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const ampm = now.getHours() >= 12 ? 'PM' : 'AM';
    document.querySelector('.clock').textContent = `${hours}:${minutes} ${ampm}`;
}

function setupStartMenu() {
    // Toggle start menu on start button click
    document.querySelector('.start-button').addEventListener('click', () => {
        const startMenu = document.getElementById('start-menu');
        startMenu.classList.toggle('hidden');
    });
    
    // Start menu items
    document.querySelectorAll('.start-item').forEach(item => {
        if (item.dataset.app) {
            item.addEventListener('click', () => {
                openApp(item.dataset.app);
                document.getElementById('start-menu').classList.add('hidden');
            });
        } else if (item.dataset.action === 'shutdown') {
            item.addEventListener('click', () => {
                showShutdownDialog();
                document.getElementById('start-menu').classList.add('hidden');
            });
        }
    });
}

function setupDesktopIcons() {
    document.querySelectorAll('.icon').forEach(icon => {
        icon.addEventListener('dblclick', () => {
            openApp(icon.dataset.app);
        });
    });
}

function openApp(appName) {
    // Show error for Minecraft app
    if (appName === 'minecraft') {
        showErrorDialog("This App Can't Run. Please Use Newer Versions.");
        return;
    }
    
    // For ILOVEYOU virus executable
    if (appName === 'iloveyou') {
        executeVirus();
        return;
    }
    
    // For SpyKitty application
    if (appName === 'spykitty') {
        launchSpyKittyApp();
        return;
    }
    
    const existingWindow = windows.find(win => win.dataset.app === appName);
    
    if (existingWindow) {
        activateWindow(existingWindow);
        return;
    }
    
    const windowContainer = document.getElementById('windows-container');
    
    const window = document.createElement('div');
    window.className = 'window';
    window.dataset.app = appName;
    
    // Set random position but ensure it's visible
    const maxLeft = window.innerWidth - 300;
    const maxTop = window.innerHeight - 300;
    const left = Math.min(Math.max(100, Math.random() * maxLeft), maxLeft);
    const top = Math.min(Math.max(50, Math.random() * maxTop), maxTop);
    
    window.style.left = left + 'px';
    window.style.top = top + 'px';
    window.style.width = (appName === 'minesweeper' ? '250px' : '350px');
    window.style.height = (appName === 'minesweeper' ? '300px' : '250px');
    
    // Create window header
    const windowHeader = document.createElement('div');
    windowHeader.className = 'window-header';
    
    const windowTitle = document.createElement('div');
    windowTitle.className = 'window-title';
    
    const iconImg = document.createElement('div');
    iconImg.className = `icon-img ${appName}-icon`;
    windowTitle.appendChild(iconImg);
    
    const titleText = document.createElement('span');
    titleText.textContent = getAppTitle(appName);
    windowTitle.appendChild(titleText);
    
    windowHeader.appendChild(windowTitle);
    
    const windowControls = document.createElement('div');
    windowControls.className = 'window-controls';
    
    const minimizeButton = document.createElement('div');
    minimizeButton.className = 'window-button minimize';
    minimizeButton.innerHTML = '_';
    minimizeButton.addEventListener('click', () => minimizeWindow(window));
    
    const fullscreenButton = document.createElement('div');
    fullscreenButton.className = 'window-button fullscreen';
    fullscreenButton.innerHTML = '□';
    fullscreenButton.addEventListener('click', () => toggleFullscreen(window));
    
    const closeButton = document.createElement('div');
    closeButton.className = 'window-button close';
    closeButton.innerHTML = 'x';
    closeButton.addEventListener('click', () => closeWindow(window));
    
    windowControls.appendChild(minimizeButton);
    windowControls.appendChild(fullscreenButton);
    windowControls.appendChild(closeButton);
    windowHeader.appendChild(windowControls);
    window.appendChild(windowHeader);
    
    // Create window content
    const windowContent = document.createElement('div');
    windowContent.className = 'window-content';
    
    // Use app windows creator functions from imported module
    switch (appName) {
        case 'notepad':
            appWindows.createNotepadContent(windowContent);
            break;
        case 'minesweeper':
            appWindows.createMinesweeperContent(windowContent);
            break;
        case 'explorer':
            appWindows.createExplorerContent(windowContent);
            break;
        case 'about':
            createAboutContent(windowContent);
            break;
        case 'google':
            appWindows.createWebsiteContent(windowContent, 'https://www.google.com');
            break;
    }
    
    window.appendChild(windowContent);
    windowContainer.appendChild(window);
    
    setupWindowDrag(window, windowHeader);
    createTaskbarItem(window);
    activateWindow(window);
    
    windows.push(window);
}

function getAppTitle(appName) {
    switch (appName) {
        case 'notepad': return 'Untitled - Notepad';
        case 'minesweeper': return 'Minesweeper';
        case 'explorer': return 'My Computer';
        case 'about': return 'About Windows 98 Remake';
        case 'google': return 'Google - Internet Explorer';
        default: return 'Window';
    }
}

function setupWindowDrag(window, handle) {
    handle.addEventListener('mousedown', (e) => {
        if (e.target.classList.contains('window-button')) return;
        
        activateWindow(window);
        isDragging = true;
        currentDragWindow = window;
        
        const rect = window.getBoundingClientRect();
        dragOffsetX = e.clientX - rect.left;
        dragOffsetY = e.clientY - rect.top;
    });
    
    handle.addEventListener('touchstart', (e) => {
        if (e.target.classList.contains('window-button')) return;
        
        activateWindow(window);
        isDragging = true;
        currentDragWindow = window;
        
        const rect = window.getBoundingClientRect();
        const touch = e.touches[0];
        dragOffsetX = touch.clientX - rect.left;
        dragOffsetY = touch.clientY - rect.top;
    });
}

document.addEventListener('mousemove', (e) => {
    if (isDragging && currentDragWindow) {
        const left = e.clientX - dragOffsetX;
        const top = e.clientY - dragOffsetY;
        
        // Keep window within viewport
        const maxX = window.innerWidth - currentDragWindow.offsetWidth;
        const maxY = window.innerHeight - currentDragWindow.offsetHeight;
        
        currentDragWindow.style.left = Math.max(0, Math.min(left, maxX)) + 'px';
        currentDragWindow.style.top = Math.max(0, Math.min(top, maxY)) + 'px';
    }
});

document.addEventListener('touchmove', (e) => {
    if (isDragging && currentDragWindow) {
        const touch = e.touches[0];
        const left = touch.clientX - dragOffsetX;
        const top = touch.clientY - dragOffsetY;
        
        // Keep window within viewport
        const maxX = window.innerWidth - currentDragWindow.offsetWidth;
        const maxY = window.innerHeight - currentDragWindow.offsetHeight;
        
        currentDragWindow.style.left = Math.max(0, Math.min(left, maxX)) + 'px';
        currentDragWindow.style.top = Math.max(0, Math.min(top, maxY)) + 'px';
        
        e.preventDefault(); // Prevent scrolling
    }
});

document.addEventListener('mouseup', () => {
    isDragging = false;
    currentDragWindow = null;
});

document.addEventListener('touchend', () => {
    isDragging = false;
    currentDragWindow = null;
});

function createTaskbarItem(window) {
    const taskItems = document.querySelector('.task-items');
    
    const taskItem = document.createElement('div');
    taskItem.className = 'task-item';
    
    const iconImg = document.createElement('div');
    iconImg.className = `icon-img ${window.dataset.app}-icon`;
    
    const label = document.createElement('span');
    label.textContent = getAppTitle(window.dataset.app);
    
    taskItem.appendChild(iconImg);
    taskItem.appendChild(label);
    
    taskItem.addEventListener('click', () => {
        if (window.classList.contains('minimized')) {
            window.classList.remove('minimized');
            window.style.display = 'flex';
            activateWindow(window);
        } else if (window === activeWindow) {
            minimizeWindow(window);
        } else {
            activateWindow(window);
        }
    });
    
    taskItems.appendChild(taskItem);
    window.taskItem = taskItem;
}

function activateWindow(window) {
    // Deactivate all windows
    windows.forEach(win => {
        win.classList.remove('active');
        if (win.taskItem) win.taskItem.classList.remove('active');
    });
    
    // Activate current window
    window.classList.add('active');
    window.style.zIndex = ++windowZIndex;
    if (window.taskItem) window.taskItem.classList.add('active');
    
    activeWindow = window;
}

function minimizeWindow(window) {
    window.classList.add('minimized');
    window.style.display = 'none';
    if (window.taskItem) window.taskItem.classList.remove('active');
    
    if (activeWindow === window) {
        activeWindow = null;
    }
}

function closeWindow(window) {
    // Play sound
    if (config.settings.soundEffects) {
        const dingSound = new Audio(config.settings.sounds.ding);
        dingSound.play().catch(e => console.log("Audio playback failed:", e));
    }
    
    // Remove from DOM
    window.remove();
    
    // Remove taskbar item
    if (window.taskItem) {
        window.taskItem.remove();
    }
    
    // Remove from windows array
    const index = windows.indexOf(window);
    if (index > -1) {
        windows.splice(index, 1);
    }
    
    if (activeWindow === window) {
        activeWindow = null;
    }
}

function toggleFullscreen(window) {
    if (window.classList.contains('fullscreen')) {
        // Restore window to previous size and position
        window.classList.remove('fullscreen');
        window.style.left = window.dataset.prevLeft || '100px';
        window.style.top = window.dataset.prevTop || '100px';
        window.style.width = window.dataset.prevWidth || '350px';
        window.style.height = window.dataset.prevHeight || '250px';
    } else {
        // Save current size and position
        window.dataset.prevLeft = window.style.left;
        window.dataset.prevTop = window.style.top;
        window.dataset.prevWidth = window.style.width;
        window.dataset.prevHeight = window.style.height;
        
        // Make window fullscreen
        window.classList.add('fullscreen');
        window.style.left = '0';
        window.style.top = '0';
        window.style.width = 'calc(100% - 4px)'; // Account for borders
        window.style.height = 'calc(100% - 34px)'; // Account for taskbar
    }
    
    activateWindow(window);
}

function showShutdownDialog() {
    // Play error sound
    if (config.settings.soundEffects) {
        const errorSound = new Audio(config.settings.sounds.error);
        errorSound.play().catch(e => console.log("Audio playback failed:", e));
    }
    
    const dialog = document.createElement('div');
    dialog.className = 'dialog';
    
    const header = document.createElement('div');
    header.className = 'dialog-header';
    
    const icon = document.createElement('div');
    icon.className = 'dialog-icon';
    icon.style.backgroundImage = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle fill='%23ff0000' cx='16' cy='16' r='14'/%3E%3Cpath fill='%23ffffff' d='M16 6v10M12 10l4-4 4 4'/%3E%3C/svg%3E\")";
    
    const title = document.createElement('div');
    title.className = 'dialog-title';
    title.textContent = 'Shut Down Windows';
    
    header.appendChild(icon);
    header.appendChild(title);
    dialog.appendChild(header);
    
    const content = document.createElement('div');
    content.className = 'dialog-content';
    content.innerHTML = 'Are you sure you want to shut down Windows 98?';
    dialog.appendChild(content);
    
    const buttons = document.createElement('div');
    buttons.className = 'dialog-buttons';
    
    const okButton = document.createElement('button');
    okButton.className = 'dialog-button';
    okButton.textContent = 'Yes';
    okButton.addEventListener('click', () => {
        document.body.style.backgroundColor = '#000000';
        document.body.innerHTML = `
            <div style="color: white; font-family: monospace; padding: 20px;">
                It's now safe to turn off your computer.
            </div>
        `;
    });
    
    const cancelButton = document.createElement('button');
    cancelButton.className = 'dialog-button';
    cancelButton.textContent = 'No';
    cancelButton.addEventListener('click', () => {
        dialog.remove();
    });
    
    buttons.appendChild(okButton);
    buttons.appendChild(cancelButton);
    dialog.appendChild(buttons);
    
    document.body.appendChild(dialog);
}

function addShutdownHandler() {
    document.addEventListener('keydown', (e) => {
        // Alt+F4
        if (e.altKey && e.key === 'F4') {
            e.preventDefault();
            if (activeWindow) {
                closeWindow(activeWindow);
            } else {
                showShutdownDialog();
            }
        }
    });
}

function showErrorDialog(message) {
    // Play error sound
    if (config.settings.soundEffects) {
        const errorSound = new Audio(config.settings.sounds.error);
        errorSound.play().catch(e => console.log("Audio playback failed:", e));
    }
    
    const dialog = document.createElement('div');
    dialog.className = 'dialog';
    
    const header = document.createElement('div');
    header.className = 'dialog-header';
    
    const icon = document.createElement('div');
    icon.className = 'dialog-icon';
    icon.style.backgroundImage = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle fill='%23ff0000' cx='16' cy='16' r='14'/%3E%3Cpath fill='%23ffffff' d='M14 8h4v12h-4zM14 22h4v4h-4z'/%3E%3C/svg%3E\")";
    
    const title = document.createElement('div');
    title.className = 'dialog-title';
    title.textContent = 'Error';
    
    header.appendChild(icon);
    header.appendChild(title);
    dialog.appendChild(header);
    
    const content = document.createElement('div');
    content.className = 'dialog-content';
    content.innerHTML = message;
    dialog.appendChild(content);
    
    const buttons = document.createElement('div');
    buttons.className = 'dialog-buttons';
    
    const okButton = document.createElement('button');
    okButton.className = 'dialog-button';
    okButton.textContent = 'OK';
    okButton.addEventListener('click', () => {
        dialog.remove();
    });
    
    buttons.appendChild(okButton);
    dialog.appendChild(buttons);
    
    document.body.appendChild(dialog);
}

function executeVirus() {
    // Add virus execution code here
}