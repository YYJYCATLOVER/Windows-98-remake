// New file for handling AboutVirus.com website content
import * as config from 'config';

export function createAboutVirusWebsite(content) {
    content.innerHTML = `
        <div class="aboutvirus-website">
            <h1>About Computer Viruses</h1>
            <p>Learn about the different types of malware that may affect your computer</p>
            
            <div class="virus-info-container">
                <div class="virus-category">
                    <h2>Common Types of Malware</h2>
                    <ul class="virus-list">
                        <li><a href="#virus">Viruses</a></li>
                        <li><a href="#worm">Worms</a></li>
                        <li><a href="#trojan">Trojans</a></li>
                        <li><a href="#spyware">Spyware</a></li>
                        <li><a href="#ransomware">Ransomware</a></li>
                        <li><a href="#wincat">WINCAT Trojan</a></li>
                        <li><a href="#wincatclean">WINCATclean (Safe)</a></li>
                        <li><a href="#lockcat">LockCat Ransomware</a></li>
                    </ul>
                </div>
                
                <div class="virus-details" id="virus-details">
                    <div class="virus-section" id="virus">
                        <h3>Computer Viruses</h3>
                        <div class="virus-icon">
                            <svg width="48" height="48" viewBox="0 0 24 24">
                                <circle cx="12" cy="12" r="10" fill="#ff6666" />
                                <path d="M12,2 L12,22 M2,12 L22,12" stroke="white" stroke-width="2" />
                            </svg>
                        </div>
                        <p>A computer virus is malicious code that replicates by copying itself to another program, document, or boot sector. 
                        Viruses often require user action to spread, such as opening an infected file.</p>
                        <p><strong>Example in our system:</strong> None currently</p>
                    </div>
                    
                    <div class="virus-section" id="worm">
                        <h3>Computer Worms</h3>
                        <div class="virus-icon">
                            <svg width="48" height="48" viewBox="0 0 24 24">
                                <path d="M12,2 C5,7 19,7 12,12 C5,17 19,17 12,22" stroke="#ff6666" stroke-width="3" fill="none" />
                            </svg>
                        </div>
                        <p>Worms are standalone malware that replicate and spread across networks without user intervention. 
                        Unlike viruses, they don't need to attach to a program.</p>
                        <p><strong>Example in our system:</strong> ILOVEYOU.EXE - A worm that duplicates itself rapidly and can crash your system. It creates multiple windows and eventually can lead to system instability.</p>
                    </div>
                    
                    <div class="virus-section" id="trojan">
                        <h3>Trojan Horses</h3>
                        <div class="virus-icon">
                            <svg width="48" height="48" viewBox="0 0 24 24">
                                <path d="M12,2 L4,10 L4,20 L20,20 L20,10 Z" stroke="#ff6666" stroke-width="2" fill="none" />
                                <path d="M8,10 L16,10" stroke="#ff6666" stroke-width="2" />
                                <path d="M12,2 L12,10" stroke="#ff6666" stroke-width="2" />
                            </svg>
                        </div>
                        <p>Trojans disguise themselves as legitimate software but contain malicious code. 
                        They often create backdoors in security to allow other malware in.</p>
                        <p><strong>Example in our system:</strong> WINCAT.EXE - A dangerous trojan that can render your system inoperable by attacking the BIOS.</p>
                    </div>
                    
                    <div class="virus-section" id="spyware">
                        <h3>Spyware</h3>
                        <div class="virus-icon">
                            <svg width="48" height="48" viewBox="0 0 24 24">
                                <circle cx="12" cy="10" r="4" stroke="#ff6666" stroke-width="2" fill="none" />
                                <path d="M12,14 L12,22" stroke="#ff6666" stroke-width="2" />
                                <path d="M8,18 L16,18" stroke="#ff6666" stroke-width="2" />
                            </svg>
                        </div>
                        <p>Spyware secretly monitors user activity and collects personal information without consent. 
                        It can track browsing habits, harvest passwords, and record keystrokes.</p>
                        <p><strong>Example in our system:</strong> BUTTERFLY.EXE - Animated butterflies that collect your personal data and system information in the background.</p>
                    </div>
                    
                    <div class="virus-section" id="ransomware">
                        <h3>Ransomware</h3>
                        <div class="virus-icon">
                            <svg width="48" height="48" viewBox="0 0 24 24">
                                <rect x="6" y="8" width="12" height="10" stroke="#ff6666" stroke-width="2" fill="none" />
                                <circle cx="12" cy="13" r="1" fill="#ff6666" />
                                <path d="M8,8 L8,6 C8,4 10,2 12,2 C14,2 16,4 16,6 L16,8" stroke="#ff6666" stroke-width="2" fill="none" />
                            </svg>
                        </div>
                        <p>Ransomware blocks access to a system or encrypts files, demanding payment for restoration. 
                        It often spreads through phishing emails or exploit kits.</p>
                        <p><strong>Example in our system:</strong> LockCat.EXE - A ransomware that encrypts your files and demands a special code to recover them before they're permanently deleted.</p>
                    </div>
                    
                    <div class="virus-section" id="wincat">
                        <h3>WINCAT Trojan</h3>
                        <div class="virus-icon">
                            <svg width="48" height="48" viewBox="0 0 24 24">
                                <circle cx="12" cy="12" r="10" fill="#ff2222" />
                                <path d="M8,12 C8,9 12,6 16,9" stroke="white" stroke-width="1.5" fill="none" />
                                <path d="M8,12 C8,15 12,18 16,15" stroke="white" stroke-width="1.5" fill="none" />
                                <circle cx="9" cy="9" r="1" fill="white" />
                                <circle cx="9" cy="15" r="1" fill="white" />
                            </svg>
                        </div>
                        <p>The WINCAT trojan is an extremely dangerous piece of malware that targets a computer's BIOS. 
                        Unlike most malware that affects only the operating system, WINCAT can render hardware completely 
                        inoperable by corrupting the BIOS firmware.</p>
                        <p><strong>Behavior:</strong> WINCAT moves through multiple stages of attack:
                            <ul>
                                <li>Opens multiple browser windows</li>
                                <li>Launches random applications</li>
                                <li>Changes system colors rapidly</li>
                                <li>Creates screen duplication effects</li>
                                <li>Displays multiple error messages</li>
                                <li>Finally corrupts the BIOS, making the computer unusable</li>
                            </ul>
                        </p>
                        <p><strong>Risk Level:</strong> Critical - Can result in permanent hardware damage</p>
                    </div>
                    
                    <div class="virus-section" id="wincatclean">
                        <h3>WINCATclean (Educational Tool)</h3>
                        <div class="virus-icon">
                            <svg width="48" height="48" viewBox="0 0 24 24">
                                <circle cx="12" cy="12" r="10" fill="#00aaff" />
                                <path d="M8,12 C8,9 12,6 16,9" stroke="white" stroke-width="1.5" fill="none" />
                                <path d="M8,12 C8,15 12,18 16,15" stroke="white" stroke-width="1.5" fill="none" />
                                <circle cx="9" cy="9" r="1" fill="white" />
                                <circle cx="9" cy="15" r="1" fill="white" />
                            </svg>
                        </div>
                        <p>WINCATclean is a <strong>safe, educational version</strong> of the WINCAT trojan, designed to demonstrate 
                        the effects of the malware without causing any actual damage to your system.</p>
                        <p><strong>Features:</strong>
                            <ul>
                                <li>Simulates visual effects of WINCAT without damaging your system</li>
                                <li>Includes buttons to trigger individual effects for educational purposes</li>
                                <li>All effects can be immediately stopped with the "Stop All Effects" button</li>
                                <li>Great for cybersecurity education and virus behavior demonstration</li>
                            </ul>
                        </p>
                        <p><strong>Risk Level:</strong> Safe - No actual damage is done to your system</p>
                        <p>You can safely download WINCATclean from <a href="https://wincatclean.com">wincatclean.com</a></p>
                    </div>
                    
                    <div class="virus-section" id="lockcat">
                        <h3>LockCat Ransomware</h3>
                        <div class="virus-icon">
                            <svg width="48" height="48" viewBox="0 0 24 24">
                                <circle cx="12" cy="12" r="10" fill="#333" />
                                <path d="M8,12 C8,9 12,7 16,9" stroke="#f55" stroke-width="1.5" fill="none" />
                                <path d="M8,12 C8,15 12,17 16,15" stroke="#f55" stroke-width="1.5" fill="none" />
                                <circle cx="9" cy="9" r="1" fill="#f55" />
                                <circle cx="9" cy="15" r="1" fill="#f55" />
                            </svg>
                        </div>
                        <p>LockCat is a sophisticated ransomware that encrypts all files on a system and displays a countdown timer. 
                        If the victim doesn't enter the correct decryption code before the timer expires, all files will be permanently deleted.</p>
                        <p><strong>Behavior:</strong> LockCat exhibits classic ransomware behavior:
                            <ul>
                                <li>Encrypts all personal files on the system</li>
                                <li>Displays a threatening message with a countdown timer</li>
                                <li>Demands a specific decryption code</li>
                                <li>Permanently deletes files if not provided with the code in time</li>
                            </ul>
                        </p>
                        <p><strong>Risk Level:</strong> Critical - Can result in permanent data loss</p>
                    </div>
                </div>
            </div>
            
            <div class="antivirus-info">
                <h2>Protection Solutions</h2>
                <p>The best way to protect your computer is to use a trusted antivirus solution like SpyKitty Antivirus.</p>
                <div class="antivirus-promo">
                    <svg width="48" height="48" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10" fill="#00aa00" />
                        <path d="M7,12 L11,16 L17,9" stroke="white" stroke-width="2" fill="none" />
                        <path d="M8,7 C10,5 14,5 16,7" stroke="white" stroke-width="1.5" fill="none" />
                        <circle cx="9" cy="9" r="1" fill="white" />
                        <circle cx="15" cy="9" r="1" fill="white" />
                    </svg>
                    <div>
                        <h3>SpyKitty Antivirus</h3>
                        <p>Comprehensive protection against all types of malware</p>
                        <a href="https://spykitty.com" class="visit-link">Visit Website</a>
                    </div>
                </div>
            </div>
            
            <div class="virus-prevention">
                <h2>How to Stay Safe Online</h2>
                <div class="prevention-tips">
                    <ul>
                        <li>Keep your operating system and applications updated</li>
                        <li>Use a reliable antivirus solution like SpyKitty</li>
                        <li>Be cautious when opening email attachments</li>
                        <li>Don't download software from untrustworthy sources</li>
                        <li>Use strong, unique passwords for all accounts</li>
                        <li>Regularly backup your important data</li>
                    </ul>
                </div>
            </div>
        </div>
    `;
    
    // Add click handlers for in-page navigation
    const links = content.querySelectorAll('.virus-list a');
    links.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            const targetElement = content.querySelector(`#${targetId}`);
            if (targetElement) {
                // Highlight the selected section
                content.querySelectorAll('.virus-section').forEach(section => {
                    section.classList.remove('active');
                });
                targetElement.classList.add('active');
                targetElement.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // Add click handler for SpyKitty link
    const spykittyLink = content.querySelector('.visit-link');
    spykittyLink.addEventListener('click', (e) => {
        e.preventDefault();
        const browserWindow = content.closest('.window');
        if (browserWindow) {
            const addressBar = browserWindow.querySelector('.google-address');
            if (addressBar) {
                addressBar.value = 'https://spykitty.com';
                
                // Force load of the SpyKitty website
                const websiteBrowser = content.closest('.website-browser');
                if (websiteBrowser) {
                    websiteBrowser.innerHTML = '';
                    import('./spykitty-app.js').then(module => {
                        module.createSpyKittyWebsite(websiteBrowser);
                    });
                }
            }
        }
    });
    
    // Add click handler for WINCATclean link
    const wincatCleanLink = content.querySelector('a[href="https://wincatclean.com"]');
    if (wincatCleanLink) {
        wincatCleanLink.addEventListener('click', (e) => {
            e.preventDefault();
            const browserWindow = content.closest('.window');
            if (browserWindow) {
                const addressBar = browserWindow.querySelector('.google-address');
                if (addressBar) {
                    addressBar.value = 'https://wincatclean.com';
                    
                    // Force load of the WINCATclean website
                    const websiteBrowser = content.closest('.website-browser');
                    if (websiteBrowser) {
                        websiteBrowser.innerHTML = '';
                        import('./wincat-clean.js').then(module => {
                            module.createWincatCleanWebsite(websiteBrowser);
                        });
                    }
                }
            }
        });
    }
}