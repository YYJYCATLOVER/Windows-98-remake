// Enhanced features for SpyKitty Antivirus
import * as config from 'config';

// Advanced scanning functionality
export function performDeepScan(container, scanType) {
    const progressBar = container.querySelector('.progress-fill');
    const statusText = container.querySelector('.scan-status');
    
    let progress = 0;
    let scanSpeed = scanType === 'quick' ? 2 : (scanType === 'full' ? 1 : 1.5);
    
    const scanFiles = [
        'C:\\Windows\\System32\\drivers',
        'C:\\Program Files\\Common Files',
        'C:\\Users\\AppData\\Roaming',
        'C:\\Windows\\Temp',
        'C:\\ProgramData',
        'C:\\Windows\\System32\\config',
        'C:\\Users\\Downloads',
        'C:\\Program Files (x86)',
        'C:\\ILOVEYOU.EXE',
        'C:\\BUTTERFLY.EXE',
        'C:\\WINCAT.EXE',
        'C:\\LOCKCAT.EXE',
        'C:\\BADDOG.EXE'
    ];
    
    let fileIndex = 0;
    let threatsFound = [];
    
    const scanInterval = setInterval(() => {
        progress += scanSpeed;
        progressBar.style.width = Math.min(progress, 100) + '%';
        
        if (progress % 8 === 0 && fileIndex < scanFiles.length) {
            statusText.textContent = 'Scanning: ' + scanFiles[fileIndex];
            
            // Check for viruses in this location
            if (fileIndex >= 8) { // Last few entries are viruses
                const virusName = scanFiles[fileIndex].split('\\').pop().split('.')[0];
                
                // Check if this virus exists in the system
                if (virusExists(virusName)) {
                    threatsFound.push({
                        name: virusName + '.EXE',
                        location: scanFiles[fileIndex],
                        type: getVirusType(virusName),
                        risk: getVirusRisk(virusName)
                    });
                }
            }
            
            fileIndex++;
        }
        
        if (progress >= 100) {
            clearInterval(scanInterval);
            completeScan(container, threatsFound);
        }
    }, 100);
    
    return scanInterval;
}

function virusExists(virusName) {
    const lowerName = virusName.toLowerCase();
    
    // Check for virus icon on desktop
    if (document.querySelector(`.icon[data-app="${lowerName}"]`)) {
        return true;
    }
    
    // Check for specific virus elements
    if (lowerName === 'butterfly' && document.querySelectorAll('.butterfly-virus').length > 0) {
        return true;
    }
    
    if (lowerName === 'baddog' && document.querySelectorAll('.infected-file-icon').length > 0) {
        return true;
    }
    
    return false;
}

function getVirusType(virusName) {
    const types = {
        'ILOVEYOU': 'Worm',
        'BUTTERFLY': 'Spyware',
        'WINCAT': 'Trojan',
        'LOCKCAT': 'Ransomware',
        'BADDOG': 'File Infector'
    };
    
    return types[virusName] || 'Unknown';
}

function getVirusRisk(virusName) {
    const risks = {
        'ILOVEYOU': 'High',
        'BUTTERFLY': 'Medium',
        'WINCAT': 'Critical',
        'LOCKCAT': 'Critical',
        'BADDOG': 'High'
    };
    
    return risks[virusName] || 'Unknown';
}

function completeScan(container, threatsFound) {
    const spykittyApp = container.closest('.spykitty-content');
    
    // Switch to threats tab
    const threatsTab = spykittyApp.querySelector('button[data-tab="threats"]');
    threatsTab.click();
    
    // Update threats list
    updateThreatsList(spykittyApp, threatsFound);
    
    // Show scan complete notification
    showNotification('Scan Complete', `Found ${threatsFound.length} threat(s)`);
}

function updateThreatsList(container, threats) {
    const threatsList = container.querySelector('.threat-items');
    const noThreats = container.querySelector('.no-threats');
    
    if (threats.length > 0) {
        noThreats.style.display = 'none';
        threatsList.innerHTML = '';
        
        threats.forEach(threat => {
            threatsList.innerHTML += `
                <div class="threat-item">
                    <div class="threat-icon">⚠️</div>
                    <div class="threat-info">
                        <h4>${threat.name}</h4>
                        <p>Type: ${threat.type}</p>
                        <p>Location: ${threat.location}</p>
                        <p>Risk: ${threat.risk}</p>
                    </div>
                    <button class="threat-action">Remove</button>
                </div>
            `;
        });
        
        // Add remove functionality
        addThreatRemovalHandlers(container);
    } else {
        noThreats.style.display = 'block';
        threatsList.innerHTML = '';
    }
}

function addThreatRemovalHandlers(container) {
    const removeButtons = container.querySelectorAll('.threat-action');
    removeButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const threatItem = e.target.closest('.threat-item');
            const threatName = threatItem.querySelector('h4').textContent;
            const virusName = threatName.split('.')[0].toLowerCase();
            
            // Remove the virus
            removeVirus(virusName);
            
            // Update the UI
            threatItem.innerHTML = `
                <div class="threat-removed">
                    <span>✓</span> ${threatName} has been successfully removed.
                </div>
            `;
            
            // If all threats are removed, show no threats message after delay
            const remainingThreats = container.querySelectorAll('.threat-action').length;
            if (remainingThreats === 0) {
                setTimeout(() => {
                    container.querySelector('.no-threats').style.display = 'block';
                    container.querySelector('.threat-items').innerHTML = '';
                }, 3000);
            }
            
            // Show notification
            showNotification('Threat Removed', `${threatName} has been successfully removed`);
        });
    });
}

function removeVirus(virusName) {
    switch(virusName) {
        case 'iloveyou':
            // Remove ILOVEYOU icon and virus windows
            const iloveyouIcon = document.querySelector('.icon[data-app="iloveyou"]');
            if (iloveyouIcon) iloveyouIcon.remove();
            document.querySelectorAll('.virus-window').forEach(vw => vw.remove());
            break;
            
        case 'butterfly':
            // Remove butterfly icon and butterflies
            const butterflyIcon = document.querySelector('.icon[data-app="butterfly"]');
            if (butterflyIcon) butterflyIcon.remove();
            document.querySelectorAll('.butterfly-virus').forEach(bv => bv.remove());
            break;
            
        case 'wincat':
            // Remove WINCAT icon and related windows
            const wincatIcon = document.querySelector('.icon[data-app="wincat"]');
            if (wincatIcon) wincatIcon.remove();
            document.querySelectorAll('.wincat-window').forEach(ww => ww.remove());
            break;
            
        case 'lockcat':
            // Remove LockCat icon and ransomware screen
            const lockcatIcon = document.querySelector('.icon[data-app="lockcat"]');
            if (lockcatIcon) lockcatIcon.remove();
            document.querySelectorAll('.lockcat-screen, .lockcat-success-screen, .lockcat-deleted-screen').forEach(ls => ls.remove());
            break;
            
        case 'baddog':
            // Remove BadDog icon and infected files
            const baddogIcon = document.querySelector('.icon[data-app="baddog"]');
            if (baddogIcon) baddogIcon.remove();
            document.querySelectorAll('.infected-file-icon').forEach(file => {
                const icon = file.closest('.icon');
                if (icon) icon.remove();
            });
            document.querySelectorAll('.baddog-takeover-screen').forEach(bt => bt.remove());
            break;
    }
}

export function showNotification(title, message) {
    const notification = document.createElement('div');
    notification.className = 'spykitty-notification';
    notification.innerHTML = `
        <div class="notification-header">
            <div class="notification-icon">
                <svg width="16" height="16" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10" fill="#00aa00" />
                    <path d="M7,12 L11,16 L17,9" stroke="white" stroke-width="2" fill="none" />
                </svg>
            </div>
            <div class="notification-title">${title}</div>
            <div class="notification-close">×</div>
        </div>
        <div class="notification-content">${message}</div>
    `;
    
    document.body.appendChild(notification);
    
    // Position in bottom right
    notification.style.position = 'fixed';
    notification.style.bottom = '10px';
    notification.style.right = '10px';
    notification.style.zIndex = '10000';
    
    // Auto remove after 4 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => notification.remove(), 500);
    }, 4000);
    
    // Add click handler to close button
    notification.querySelector('.notification-close').addEventListener('click', () => {
        notification.remove();
    });
    
    // Play notification sound
    if (config.settings.soundEffects) {
        const dingSound = new Audio(config.settings.sounds.ding);
        dingSound.volume = 0.5;
        dingSound.play().catch(e => console.log("Audio playback failed:", e));
    }
}

export function setupRealTimeProtection(container) {
    const statusItem = container.querySelector('.status-item:first-child .status-on');
    
    // Create an observer to watch for new elements that might be viruses
    const observer = new MutationObserver((mutations) => {
        mutations.forEach(mutation => {
            if (mutation.addedNodes.length) {
                mutation.addedNodes.forEach(node => {
                    if (node.nodeType === 1) { // Element node
                        // Check for virus indicators
                        checkForViruses(node);
                    }
                });
            }
        });
    });
    
    // Start observing
    observer.observe(document.body, { 
        childList: true, 
        subtree: true 
    });
    
    return {
        isActive: true,
        observer: observer,
        statusIndicator: statusItem
    };
}

function checkForViruses(element) {
    // Check if realtime protection is enabled
    const protectionSetting = document.querySelector('.setting-item:first-child input');
    if (!protectionSetting || !protectionSetting.checked) return;
    
    // Look for virus indicators in the added element
    if (element.dataset && element.dataset.app) {
        const app = element.dataset.app.toLowerCase();
        const virusApps = ['iloveyou', 'butterfly', 'wincat', 'lockcat', 'baddog'];
        
        if (virusApps.includes(app)) {
            // Block and remove the virus
            setTimeout(() => {
                element.remove();
                showNotification('Threat Blocked', `SpyKitty blocked ${app.toUpperCase()}.EXE from installing`);
            }, 500);
        }
    }
    
    // Check for specific virus classes
    const virusClasses = [
        'virus-window', 'butterfly-virus', 'wincat-window', 
        'lockcat-screen', 'infected-file-icon', 'baddog-takeover-screen'
    ];
    
    for (const cls of virusClasses) {
        if (element.classList && element.classList.contains(cls)) {
            // Block and remove the virus element
            setTimeout(() => {
                element.remove();
                showNotification('Threat Blocked', `SpyKitty blocked a virus from executing`);
            }, 500);
            break;
        }
    }
}

export function createScheduledScanScreen(content) {
    const scheduledTab = document.createElement('div');
    scheduledTab.className = 'spykitty-tab-content hidden';
    scheduledTab.id = 'scheduled-tab';
    
    scheduledTab.innerHTML = `
        <div class="scheduled-scans">
            <h3>Scheduled Scans</h3>
            <p>Configure automatic scans to keep your system protected at all times.</p>
            
            <div class="schedule-settings">
                <div class="setting-item">
                    <label>
                        <input type="checkbox" id="enable-schedule"> Enable Scheduled Scans
                    </label>
                </div>
                
                <div class="schedule-options">
                    <div class="schedule-option">
                        <label>Frequency:</label>
                        <select id="scan-frequency">
                            <option value="daily">Daily</option>
                            <option value="weekly" selected>Weekly</option>
                            <option value="monthly">Monthly</option>
                        </select>
                    </div>
                    
                    <div class="schedule-option">
                        <label>Time:</label>
                        <select id="scan-time">
                            <option value="00:00">12:00 AM</option>
                            <option value="01:00">1:00 AM</option>
                            <option value="02:00" selected>2:00 AM</option>
                            <option value="12:00">12:00 PM</option>
                            <option value="18:00">6:00 PM</option>
                        </select>
                    </div>
                    
                    <div class="schedule-option">
                        <label>Scan Type:</label>
                        <select id="scheduled-scan-type">
                            <option value="quick" selected>Quick Scan</option>
                            <option value="full">Full System Scan</option>
                        </select>
                    </div>
                </div>
                
                <div class="schedule-actions">
                    <button id="save-schedule" class="primary-button">Save Schedule</button>
                </div>
            </div>
            
            <div class="schedule-history">
                <h4>Scan History</h4>
                <table class="history-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Type</th>
                            <th>Threats</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>${new Date().toLocaleDateString()}</td>
                            <td>2:00 AM</td>
                            <td>Quick Scan</td>
                            <td>0</td>
                            <td class="status-completed">Completed</td>
                        </tr>
                        <tr>
                            <td>${new Date(Date.now() - 86400000).toLocaleDateString()}</td>
                            <td>2:00 AM</td>
                            <td>Quick Scan</td>
                            <td>0</td>
                            <td class="status-completed">Completed</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    `;
    
    return scheduledTab;
}

export function createQuarantineScreen(content) {
    const quarantineTab = document.createElement('div');
    quarantineTab.className = 'spykitty-tab-content hidden';
    quarantineTab.id = 'quarantine-tab';
    
    quarantineTab.innerHTML = `
        <div class="quarantine-area">
            <h3>Quarantined Items</h3>
            <p>Items in quarantine are isolated and cannot harm your system. You can restore or permanently delete them.</p>
            
            <div class="quarantine-empty">
                <svg width="64" height="64" viewBox="0 0 24 24">
                    <rect x="4" y="4" width="16" height="16" fill="#eeeeee" stroke="#cccccc" stroke-width="1" />
                    <circle cx="12" cy="12" r="3" fill="#cccccc" />
                    <line x1="8" y1="8" x2="16" y2="16" stroke="#cccccc" stroke-width="1" />
                    <line x1="16" y1="8" x2="8" y2="16" stroke="#cccccc" stroke-width="1" />
                </svg>
                <p>No items in quarantine</p>
            </div>
            
            <div class="quarantine-list hidden">
                <table class="quarantine-table">
                    <thead>
                        <tr>
                            <th>Threat Name</th>
                            <th>Original Location</th>
                            <th>Date Quarantined</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Quarantined items will appear here -->
                    </tbody>
                </table>
            </div>
            
            <div class="quarantine-actions">
                <button id="clear-quarantine" disabled>Clear All</button>
            </div>
        </div>
    `;
    
    return quarantineTab;
}

export function createUpdateScreen(content) {
    const updateTab = document.createElement('div');
    updateTab.className = 'spykitty-tab-content hidden';
    updateTab.id = 'update-tab';
    
    updateTab.innerHTML = `
        <div class="update-area">
            <h3>Virus Definitions</h3>
            <div class="update-status">
                <div class="update-icon">
                    <svg width="48" height="48" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10" fill="#00aa00" />
                        <path d="M7,12 L11,16 L17,9" stroke="white" stroke-width="2" fill="none" />
                    </svg>
                </div>
                <div class="update-info">
                    <h4>Your definitions are up to date</h4>
                    <p>Last updated: ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}</p>
                    <p>Version: 2023.11.${Math.floor(Math.random() * 30) + 1}.001</p>
                </div>
            </div>
            
            <div class="update-actions">
                <button id="check-updates" class="primary-button">Check for Updates</button>
            </div>
            
            <div class="update-settings">
                <h4>Update Settings</h4>
                <div class="setting-item">
                    <label>
                        <input type="checkbox" checked> Automatically download and install updates
                    </label>
                </div>
                <div class="setting-item">
                    <label>Check frequency:</label>
                    <select>
                        <option value="daily" selected>Daily</option>
                        <option value="weekly">Weekly</option>
                    </select>
                </div>
            </div>
        </div>
    `;
    
    return updateTab;
}