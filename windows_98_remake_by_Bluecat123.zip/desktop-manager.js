// New file to manage desktop icons and related functionality
import * as config from 'config';

// Function to create a desktop icon for an app
export function createDesktopIcon(appName, displayName, iconClass) {
    const icons = document.querySelector('.icons');
    
    const appIcon = document.createElement('div');
    appIcon.className = 'icon';
    appIcon.dataset.app = appName;
    
    const iconImg = document.createElement('div');
    iconImg.className = `icon-img ${iconClass || appName + '-icon'}`;
    
    const iconText = document.createElement('span');
    iconText.textContent = displayName || appName.toUpperCase() + '.EXE';
    
    appIcon.appendChild(iconImg);
    appIcon.appendChild(iconText);
    
    appIcon.addEventListener('dblclick', () => {
        if (window[`launch${appName.charAt(0).toUpperCase() + appName.slice(1)}`]) {
            window[`launch${appName.charAt(0).toUpperCase() + appName.slice(1)}`]();
        } else if (window.openApp) {
            window.openApp(appName);
        }
    });
    
    icons.appendChild(appIcon);
    return appIcon;
}

// Function to check if a desktop icon exists
export function desktopIconExists(appName) {
    return !!document.querySelector(`.icon[data-app="${appName}"]`);
}

// Create download notification that adds app to desktop
export function showDownloadNotification(appName, title, executeFunction, iconClass) {
    // Play sound
    if (config.settings.soundEffects) {
        const dingSound = new Audio(config.settings.sounds.ding);
        dingSound.play().catch(e => console.log("Audio playback failed:", e));
    }
    
    const dialog = document.createElement('div');
    dialog.className = 'dialog';
    
    const header = document.createElement('div');
    header.className = 'dialog-header';
    
    const icon = document.createElement('div');
    icon.className = 'dialog-icon';
    icon.style.backgroundImage = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect fill='%23008000' width='32' height='32'/%3E%3Cpath fill='%23ffffff' d='M6 16L14 24L26 8'/%3E%3C/svg%3E\")";
    
    const titleElement = document.createElement('div');
    titleElement.className = 'dialog-title';
    titleElement.textContent = title || 'Download Complete';
    
    header.appendChild(icon);
    header.appendChild(titleElement);
    dialog.appendChild(header);
    
    const content = document.createElement('div');
    content.className = 'dialog-content';
    content.innerHTML = `${appName.toUpperCase()}.EXE has been downloaded successfully.<br>Would you like to run it now?`;
    dialog.appendChild(content);
    
    const buttons = document.createElement('div');
    buttons.className = 'dialog-buttons';
    
    const okButton = document.createElement('button');
    okButton.className = 'dialog-button';
    okButton.textContent = 'Run';
    okButton.addEventListener('click', () => {
        dialog.remove();
        if (executeFunction && typeof executeFunction === 'function') {
            executeFunction();
        }
    });
    
    const cancelButton = document.createElement('button');
    cancelButton.className = 'dialog-button';
    cancelButton.textContent = 'Cancel';
    cancelButton.addEventListener('click', () => {
        dialog.remove();
        createDesktopIcon(appName, appName.toUpperCase() + '.EXE', iconClass);
    });
    
    buttons.appendChild(okButton);
    buttons.appendChild(cancelButton);
    dialog.appendChild(buttons);
    
    document.body.appendChild(dialog);
}